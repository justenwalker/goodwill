--
-- PostgreSQL database dump
--

-- Dumped from database version 10.16
-- Dumped by pg_dump version 10.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: out_variables_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.out_variables_mode AS ENUM (
    'DISABLED',
    'OWNERS',
    'TEAM_MEMBERS',
    'ORG_MEMBERS',
    'EVERYONE'
);


ALTER TYPE public.out_variables_mode OWNER TO postgres;

--
-- Name: process_lock_scope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.process_lock_scope AS ENUM (
    'ORG',
    'PROJECT'
);


ALTER TYPE public.process_lock_scope OWNER TO postgres;

--
-- Name: raw_payload_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.raw_payload_mode AS ENUM (
    'DISABLED',
    'OWNERS',
    'TEAM_MEMBERS',
    'ORG_MEMBERS',
    'EVERYONE'
);


ALTER TYPE public.raw_payload_mode OWNER TO postgres;

--
-- Name: task_status_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.task_status_type AS ENUM (
    'OK',
    'ERROR',
    'RUNNING',
    'STALLED'
);


ALTER TYPE public.task_status_type OWNER TO postgres;

--
-- Name: process_log_data_last_n_bytes(uuid, timestamp without time zone, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_last_n_bytes(p_instance_id uuid, p_created_at timestamp without time zone, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(LOG_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                    INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START - P_DATA_LEN, R_START);
            end;
            $$;


ALTER FUNCTION public.process_log_data_last_n_bytes(p_instance_id uuid, p_created_at timestamp without time zone, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_last_n_bytes(uuid, timestamp with time zone, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_last_n_bytes(p_instance_id uuid, p_created_at timestamp with time zone, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(LOG_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START - P_DATA_LEN, R_START);
            end;
            $$;


ALTER FUNCTION public.process_log_data_last_n_bytes(p_instance_id uuid, p_created_at timestamp with time zone, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_next_range(uuid, timestamp without time zone, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_next_range(p_instance_id uuid, p_created_at timestamp without time zone, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
            R_START int;
            begin
                select coalesce(max(upper(LOG_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                    INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START, R_START + P_DATA_LEN);
            end;
            $$;


ALTER FUNCTION public.process_log_data_next_range(p_instance_id uuid, p_created_at timestamp without time zone, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_next_range(uuid, timestamp with time zone, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_next_range(p_instance_id uuid, p_created_at timestamp with time zone, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(LOG_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START, R_START + P_DATA_LEN);
            end;
            $$;


ALTER FUNCTION public.process_log_data_next_range(p_instance_id uuid, p_created_at timestamp with time zone, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_segment_last_n_bytes(uuid, timestamp without time zone, bigint, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_segment_last_n_bytes(p_instance_id uuid, p_created_at timestamp without time zone, p_segment_id bigint, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(SEGMENT_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                    INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT and SEGMENT_ID = P_SEGMENT_ID;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START - P_DATA_LEN, R_START);
            end;
            $$;


ALTER FUNCTION public.process_log_data_segment_last_n_bytes(p_instance_id uuid, p_created_at timestamp without time zone, p_segment_id bigint, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_segment_last_n_bytes(uuid, timestamp with time zone, bigint, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_segment_last_n_bytes(p_instance_id uuid, p_created_at timestamp with time zone, p_segment_id bigint, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(SEGMENT_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT and SEGMENT_ID = P_SEGMENT_ID;

                if R_START is null then
                R_START := 0;
                end if;

                return int4range(R_START - P_DATA_LEN, R_START);
            end;
            $$;


ALTER FUNCTION public.process_log_data_segment_last_n_bytes(p_instance_id uuid, p_created_at timestamp with time zone, p_segment_id bigint, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_segment_next_range(uuid, timestamp without time zone, bigint, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_segment_next_range(p_instance_id uuid, p_created_at timestamp without time zone, p_segment_id bigint, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(SEGMENT_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                    INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT and SEGMENT_ID = P_SEGMENT_ID;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START, R_START + P_DATA_LEN);
            end;
            $$;


ALTER FUNCTION public.process_log_data_segment_next_range(p_instance_id uuid, p_created_at timestamp without time zone, p_segment_id bigint, p_data_len integer) OWNER TO postgres;

--
-- Name: process_log_data_segment_next_range(uuid, timestamp with time zone, bigint, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_log_data_segment_next_range(p_instance_id uuid, p_created_at timestamp with time zone, p_segment_id bigint, p_data_len integer) RETURNS int4range
    LANGUAGE plpgsql
    AS $$
            declare
                R_START int;
            begin
                select coalesce(max(upper(SEGMENT_RANGE)), 0) into R_START
                from PROCESS_LOG_DATA
                where
                INSTANCE_ID = P_INSTANCE_ID and INSTANCE_CREATED_AT = P_CREATED_AT and SEGMENT_ID = P_SEGMENT_ID;

                if R_START is null then
                    R_START := 0;
                end if;

                return int4range(R_START, R_START + P_DATA_LEN);
            end;
            $$;


ALTER FUNCTION public.process_log_data_segment_next_range(p_instance_id uuid, p_created_at timestamp with time zone, p_segment_id bigint, p_data_len integer) OWNER TO postgres;

--
-- Name: ts_to_tstz(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ts_to_tstz(t text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
            declare
                v_cnt numeric;
            begin
                v_cnt := 0;

                update pg_attribute
                    set atttypid = 'timestamp with time zone'::regtype
                from pg_class
                where attrelid = pg_class.oid
                    and relnamespace = current_schema()::regnamespace
                    and atttypid = 'timestamp'::regtype
                    and relname ilike t;

                get diagnostics v_cnt = row_count;
                if v_cnt = 0 then
                    raise warning 'Relation not found (or is already converted): %', t;
                end if;

                update pg_index
                    set indclass = array_to_string(array_replace(indclass::oid[], 3128::oid, 3127::oid), ' ')::oidvector
                from pg_class
                where indrelid = pg_class.oid
                    and relnamespace = current_schema()::regnamespace
                    and indclass::oid[] @> ARRAY[3128::oid]
                    and relname ilike t;

                return v_cnt > 0;
            end;
            $$;


ALTER FUNCTION public.ts_to_tstz(t text) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    user_id uuid NOT NULL
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- Name: agent_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_commands (
    command_id uuid NOT NULL,
    agent_id character varying(36) NOT NULL,
    command_status character varying(32) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    command_data bytea NOT NULL
);


ALTER TABLE public.agent_commands OWNER TO postgres;

--
-- Name: ansible_hosts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ansible_hosts (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    host character varying(1024) NOT NULL,
    host_group character varying(1024) NOT NULL,
    event_seq bigint NOT NULL,
    status character varying(32) NOT NULL,
    duration bigint NOT NULL,
    playbook_id uuid NOT NULL
);


ALTER TABLE public.ansible_hosts OWNER TO postgres;

--
-- Name: ansible_play_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ansible_play_stats (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    playbook_id uuid NOT NULL,
    play_id uuid NOT NULL,
    play_name character varying(1024),
    play_order integer NOT NULL,
    host_count bigint NOT NULL,
    task_count integer NOT NULL,
    finished_task_count bigint NOT NULL
);


ALTER TABLE public.ansible_play_stats OWNER TO postgres;

--
-- Name: ansible_playbook_result; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ansible_playbook_result (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    playbook_id uuid NOT NULL,
    status character varying(64) NOT NULL
);


ALTER TABLE public.ansible_playbook_result OWNER TO postgres;

--
-- Name: ansible_playbook_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ansible_playbook_stats (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    playbook_id uuid NOT NULL,
    name character varying(1024) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    host_count integer NOT NULL,
    play_count integer NOT NULL,
    total_work integer NOT NULL,
    retry_num integer
);


ALTER TABLE public.ansible_playbook_stats OWNER TO postgres;

--
-- Name: ansible_task_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ansible_task_stats (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    playbook_id uuid NOT NULL,
    play_id uuid NOT NULL,
    task_id uuid NOT NULL,
    task_name character varying(1024) NOT NULL,
    task_order bigint NOT NULL,
    task_type character varying(64) NOT NULL,
    ok_count bigint NOT NULL,
    failed_count bigint NOT NULL,
    unreachable_count bigint NOT NULL,
    skipped_count bigint NOT NULL,
    running_count bigint NOT NULL
);


ALTER TABLE public.ansible_task_stats OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    key_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    api_key character varying(64) NOT NULL,
    user_id uuid NOT NULL,
    key_name character varying(128) DEFAULT 'n/a'::character varying NOT NULL,
    expired_at timestamp with time zone,
    last_notified_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: TABLE api_keys; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.api_keys IS 'API access keys';


--
-- Name: COLUMN api_keys.key_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.api_keys.key_id IS 'Unique key ID';


--
-- Name: COLUMN api_keys.api_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.api_keys.api_key IS 'SHA-256 hash of a key';


--
-- Name: COLUMN api_keys.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.api_keys.user_id IS 'ID of a key''s user';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    entry_date timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid,
    entry_object character varying(128) NOT NULL,
    entry_action character varying(128) NOT NULL,
    entry_details jsonb,
    entry_seq bigint NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: COLUMN audit_log.entry_seq; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.audit_log.entry_seq IS 'Add sequences to enable forwarding';


--
-- Name: audit_log_entry_seq_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_entry_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_entry_seq_seq OWNER TO postgres;

--
-- Name: audit_log_entry_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_entry_seq_seq OWNED BY public.audit_log.entry_seq;


--
-- Name: event_processor_marker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_processor_marker (
    processor_name character varying(64) NOT NULL,
    event_seq bigint NOT NULL
);


ALTER TABLE public.event_processor_marker OWNER TO postgres;

--
-- Name: json_stores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.json_stores (
    json_store_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    json_store_name character varying(128) NOT NULL,
    parent_inventory_id uuid,
    org_id uuid DEFAULT '0fac1b18-d179-11e7-b3e7-d7df4543ed4f'::uuid NOT NULL,
    visibility character varying(128) DEFAULT 'PUBLIC'::character varying NOT NULL,
    owner_id uuid
);


ALTER TABLE public.json_stores OWNER TO postgres;

--
-- Name: TABLE json_stores; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.json_stores IS 'Inventories';


--
-- Name: COLUMN json_stores.json_store_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_stores.json_store_id IS 'Unique ID of the inventory';


--
-- Name: COLUMN json_stores.json_store_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_stores.json_store_name IS 'Unique name of the inventory';


--
-- Name: COLUMN json_stores.parent_inventory_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_stores.parent_inventory_id IS 'ID of the parent inventory';


--
-- Name: inventories; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.inventories AS
 SELECT json_stores.json_store_id AS inventory_id,
    json_stores.json_store_name AS inventory_name,
    NULL::text AS parent_inventory_id,
    json_stores.org_id,
    json_stores.visibility,
    json_stores.owner_id
   FROM public.json_stores;


ALTER TABLE public.inventories OWNER TO postgres;

--
-- Name: json_store_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.json_store_data (
    json_store_id uuid NOT NULL,
    item_path character varying(1024) NOT NULL,
    item_data jsonb NOT NULL,
    item_data_size bigint
);


ALTER TABLE public.json_store_data OWNER TO postgres;

--
-- Name: TABLE json_store_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.json_store_data IS 'Inventory data';


--
-- Name: COLUMN json_store_data.json_store_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_data.json_store_id IS 'FK to an inventory';


--
-- Name: COLUMN json_store_data.item_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_data.item_path IS 'Unique (for an inventory) path to an entry';


--
-- Name: COLUMN json_store_data.item_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_data.item_data IS 'JSON data';


--
-- Name: json_store_data_view_restricted; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.json_store_data_view_restricted AS
 SELECT json_store_data.json_store_id,
    json_store_data.item_path,
    json_store_data.item_data,
    json_store_data.item_data_size
   FROM public.json_store_data
  WHERE (json_store_data.json_store_id = (current_setting('jsonStoreQueryExec.json_store_id'::text))::uuid);


ALTER TABLE public.json_store_data_view_restricted OWNER TO postgres;

--
-- Name: inventory_data; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.inventory_data AS
 SELECT json_store_data_view_restricted.json_store_id AS inventory_id,
    json_store_data_view_restricted.item_path,
    json_store_data_view_restricted.item_data
   FROM public.json_store_data_view_restricted;


ALTER TABLE public.inventory_data OWNER TO postgres;

--
-- Name: json_store_queries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.json_store_queries (
    query_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    json_store_id uuid NOT NULL,
    query_name character varying(256) NOT NULL,
    query_text character varying(4000) NOT NULL
);


ALTER TABLE public.json_store_queries OWNER TO postgres;

--
-- Name: TABLE json_store_queries; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.json_store_queries IS 'Inventory queries';


--
-- Name: COLUMN json_store_queries.query_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_queries.query_id IS 'Unique query index';


--
-- Name: COLUMN json_store_queries.json_store_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_queries.json_store_id IS 'FK to an inventory';


--
-- Name: COLUMN json_store_queries.query_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_queries.query_name IS 'Unique (for an inventory) query name';


--
-- Name: COLUMN json_store_queries.query_text; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.json_store_queries.query_text IS 'Query text';


--
-- Name: inventory_queries; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.inventory_queries AS
 SELECT json_store_queries.query_id,
    json_store_queries.json_store_id AS inventory_id,
    json_store_queries.query_name,
    json_store_queries.query_text
   FROM public.json_store_queries;


ALTER TABLE public.inventory_queries OWNER TO postgres;

--
-- Name: json_store_team_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.json_store_team_access (
    json_store_id uuid NOT NULL,
    team_id uuid NOT NULL,
    access_level character varying(128) DEFAULT 'READER'::character varying NOT NULL
);


ALTER TABLE public.json_store_team_access OWNER TO postgres;

--
-- Name: node_roster_host_artifacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.node_roster_host_artifacts (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    host_id uuid NOT NULL,
    artifact_url character varying(1024) NOT NULL
);


ALTER TABLE public.node_roster_host_artifacts OWNER TO postgres;

--
-- Name: node_roster_host_facts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.node_roster_host_facts (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    host_id uuid NOT NULL,
    facts jsonb NOT NULL,
    seq_id integer NOT NULL
);


ALTER TABLE public.node_roster_host_facts OWNER TO postgres;

--
-- Name: node_roster_host_facts_seq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.node_roster_host_facts_seq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.node_roster_host_facts_seq_id_seq OWNER TO postgres;

--
-- Name: node_roster_host_facts_seq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.node_roster_host_facts_seq_id_seq OWNED BY public.node_roster_host_facts.seq_id;


--
-- Name: node_roster_hosts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.node_roster_hosts (
    host_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    normalized_hostname character varying(2048) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.node_roster_hosts OWNER TO postgres;

--
-- Name: node_roster_process_hosts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.node_roster_process_hosts (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    host_id uuid NOT NULL,
    initiator character varying(64),
    initiator_id uuid,
    project_id uuid
);


ALTER TABLE public.node_roster_process_hosts OWNER TO postgres;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    org_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    org_name character varying(128) NOT NULL,
    visibility character varying(128) DEFAULT 'PUBLIC'::character varying NOT NULL,
    meta jsonb,
    org_cfg jsonb,
    owner_id uuid
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    permission_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    permission_name character varying(256) NOT NULL,
    description character varying(1024) NOT NULL
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.permissions IS 'Dictionary of permissions';


--
-- Name: policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policies (
    policy_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    policy_name character varying(256) NOT NULL,
    rules jsonb NOT NULL,
    parent_policy_id uuid
);


ALTER TABLE public.policies OWNER TO postgres;

--
-- Name: policy_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policy_links (
    org_id uuid,
    project_id uuid,
    policy_id uuid NOT NULL,
    user_id uuid
);


ALTER TABLE public.policy_links OWNER TO postgres;

--
-- Name: process_checkpoints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_checkpoints (
    checkpoint_id uuid NOT NULL,
    instance_id uuid NOT NULL,
    checkpoint_data bytea NOT NULL,
    checkpoint_name character varying(128),
    checkpoint_date timestamp with time zone,
    instance_created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.process_checkpoints OWNER TO postgres;

--
-- Name: COLUMN process_checkpoints.instance_created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_checkpoints.instance_created_at IS 'Same as PROCESS_QUEUE.CREATED_AT';


--
-- Name: process_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_events (
    instance_id uuid NOT NULL,
    event_type character varying(36) NOT NULL,
    event_date timestamp with time zone NOT NULL,
    event_data jsonb NOT NULL,
    event_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    event_seq bigint NOT NULL,
    instance_created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.process_events OWNER TO postgres;

--
-- Name: COLUMN process_events.event_seq; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_events.event_seq IS 'Add sequences to enable forwarding';


--
-- Name: process_events_event_seq_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_events_event_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.process_events_event_seq_seq OWNER TO postgres;

--
-- Name: process_events_event_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_events_event_seq_seq OWNED BY public.process_events.event_seq;


--
-- Name: process_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_locks (
    instance_id uuid NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    lock_scope public.process_lock_scope NOT NULL,
    lock_name character varying(128) NOT NULL
);


ALTER TABLE public.process_locks OWNER TO postgres;

--
-- Name: process_log_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_log_data (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    segment_id bigint NOT NULL,
    log_range int4range NOT NULL,
    segment_range int4range NOT NULL,
    chunk_data bytea NOT NULL,
    log_seq bigint NOT NULL
);


ALTER TABLE public.process_log_data OWNER TO postgres;

--
-- Name: process_log_data_log_seq_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_log_data_log_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.process_log_data_log_seq_seq OWNER TO postgres;

--
-- Name: process_log_data_log_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_log_data_log_seq_seq OWNED BY public.process_log_data.log_seq;


--
-- Name: process_log_data_segment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_log_data_segment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.process_log_data_segment_id_seq OWNER TO postgres;

--
-- Name: process_log_data_segment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_log_data_segment_id_seq OWNED BY public.process_log_data.segment_id;


--
-- Name: process_log_segments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_log_segments (
    instance_id uuid NOT NULL,
    instance_created_at timestamp with time zone NOT NULL,
    segment_id bigint NOT NULL,
    segment_name text NOT NULL,
    correlation_id uuid,
    segment_ts timestamp with time zone NOT NULL,
    segment_status text,
    segment_errors integer,
    segment_warn integer
);


ALTER TABLE public.process_log_segments OWNER TO postgres;

--
-- Name: process_log_segments_segment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_log_segments_segment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.process_log_segments_segment_id_seq OWNER TO postgres;

--
-- Name: process_log_segments_segment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_log_segments_segment_id_seq OWNED BY public.process_log_segments.segment_id;


--
-- Name: process_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_queue (
    instance_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    current_status character varying(32) NOT NULL,
    last_agent_id character varying(128),
    last_updated_at timestamp with time zone NOT NULL,
    parent_instance_id uuid,
    process_kind character varying(128),
    process_tags text[],
    project_id uuid,
    start_at timestamp with time zone,
    requirements jsonb,
    repo_id uuid,
    repo_url character varying(2048),
    repo_path character varying(2048),
    commit_id character varying(64),
    commit_msg character varying(128),
    initiator_id uuid,
    meta jsonb,
    timeout bigint,
    handlers text[],
    last_run_at timestamp with time zone,
    wait_conditions jsonb,
    is_disabled boolean DEFAULT false NOT NULL,
    imports jsonb,
    triggered_by jsonb,
    exclusive jsonb,
    runtime text,
    id_seq bigint NOT NULL,
    dependencies text[],
    commit_branch character varying(255),
    suspend_timeout bigint
);


ALTER TABLE public.process_queue OWNER TO postgres;

--
-- Name: COLUMN process_queue.instance_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.instance_id IS 'Unique process ID';


--
-- Name: COLUMN process_queue.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.created_at IS 'Timestamp of process creation';


--
-- Name: COLUMN process_queue.current_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.current_status IS 'Current status of a process';


--
-- Name: COLUMN process_queue.last_agent_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.last_agent_id IS 'ID of the last agent that was executing the process';


--
-- Name: COLUMN process_queue.last_updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.last_updated_at IS 'Timestamp of the last update';


--
-- Name: COLUMN process_queue.timeout; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.timeout IS 'Timeout (in seconds)';


--
-- Name: COLUMN process_queue.handlers; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_queue.handlers IS 'List of process handlers';


--
-- Name: process_queue_id_seq_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_queue_id_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.process_queue_id_seq_seq OWNER TO postgres;

--
-- Name: process_queue_id_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_queue_id_seq_seq OWNED BY public.process_queue.id_seq;


--
-- Name: process_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_state (
    instance_id uuid NOT NULL,
    item_path character varying(2048) NOT NULL,
    item_data bytea NOT NULL,
    unix_mode numeric(4,0) DEFAULT 420 NOT NULL,
    is_encrypted boolean DEFAULT false NOT NULL,
    instance_created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.process_state OWNER TO postgres;

--
-- Name: COLUMN process_state.instance_created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.process_state.instance_created_at IS 'Same as PROCESS_QUEUE.CREATED_AT';


--
-- Name: project_kv_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_kv_store (
    value_key character varying(128) NOT NULL,
    value_long numeric(16,0),
    value_string character varying(1024),
    project_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL
);


ALTER TABLE public.project_kv_store OWNER TO postgres;

--
-- Name: TABLE project_kv_store; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.project_kv_store IS 'KV store';


--
-- Name: project_team_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_team_access (
    project_id uuid NOT NULL,
    team_id uuid NOT NULL,
    access_level character varying(128) DEFAULT 'READER'::character varying NOT NULL
);


ALTER TABLE public.project_team_access OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    project_name character varying(128) NOT NULL,
    description character varying(1024),
    project_cfg jsonb,
    project_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    visibility character varying(128) DEFAULT 'PUBLIC'::character varying NOT NULL,
    org_id uuid DEFAULT '0fac1b18-d179-11e7-b3e7-d7df4543ed4f'::uuid NOT NULL,
    owner_id uuid,
    secret_key bytea,
    meta jsonb,
    raw_payload_mode public.raw_payload_mode DEFAULT 'DISABLED'::public.raw_payload_mode NOT NULL,
    out_variables_mode public.out_variables_mode DEFAULT 'DISABLED'::public.out_variables_mode NOT NULL
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: COLUMN projects.project_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.projects.project_name IS 'Name (key) of a project';


--
-- Name: repositories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repositories (
    repo_name character varying(128) NOT NULL,
    repo_url character varying(2048) NOT NULL,
    repo_branch character varying(255),
    repo_commit_id character varying(64),
    repo_path character varying(2048),
    project_id uuid NOT NULL,
    repo_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    secret_id uuid,
    webhook_id bigint,
    meta jsonb,
    is_disabled boolean DEFAULT false NOT NULL,
    CONSTRAINT repo_branch_commit_check CHECK (((repo_branch IS NOT NULL) OR (repo_commit_id IS NOT NULL)))
);


ALTER TABLE public.repositories OWNER TO postgres;

--
-- Name: COLUMN repositories.repo_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.repositories.repo_name IS 'Name (key) of a repository';


--
-- Name: COLUMN repositories.repo_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.repositories.repo_url IS 'URL of a repository';


--
-- Name: COLUMN repositories.repo_branch; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.repositories.repo_branch IS 'Name of a repository''s branch';


--
-- Name: COLUMN repositories.repo_commit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.repositories.repo_commit_id IS 'Repository''s commit id';


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.role_permissions IS 'Permissions of roles';


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    role_name character varying(256) NOT NULL,
    global_reader boolean DEFAULT false,
    global_writer boolean DEFAULT false
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: secret_team_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.secret_team_access (
    secret_id uuid NOT NULL,
    team_id uuid NOT NULL,
    access_level character varying(128) DEFAULT 'READER'::character varying NOT NULL
);


ALTER TABLE public.secret_team_access OWNER TO postgres;

--
-- Name: secrets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.secrets (
    secret_name character varying(128) NOT NULL,
    secret_type character varying(32) NOT NULL,
    secret_data bytea,
    encrypted_by character varying(128) DEFAULT 'SERVER_KEY'::character varying NOT NULL,
    secret_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    org_id uuid DEFAULT '0fac1b18-d179-11e7-b3e7-d7df4543ed4f'::uuid NOT NULL,
    owner_id uuid,
    visibility character varying(128) DEFAULT 'PUBLIC'::character varying NOT NULL,
    store_type character varying(128) DEFAULT 'CONCORD'::character varying,
    project_id uuid
);


ALTER TABLE public.secrets OWNER TO postgres;

--
-- Name: COLUMN secrets.secret_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.secrets.secret_name IS 'Name (key) of a secret';


--
-- Name: COLUMN secrets.secret_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.secrets.secret_type IS 'Type: SSH_KEY, HTTP_BASIC';


--
-- Name: server_db_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.server_db_lock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.server_db_lock OWNER TO postgres;

--
-- Name: server_db_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.server_db_log (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.server_db_log OWNER TO postgres;

--
-- Name: task_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_locks (
    lock_key character varying(64) NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    locked_at timestamp with time zone,
    lock_counter integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_locks OWNER TO postgres;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    task_id character varying(64) NOT NULL,
    task_interval bigint NOT NULL,
    task_status public.task_status_type,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    last_updated_at timestamp with time zone,
    last_error_at timestamp with time zone,
    last_error text
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: COLUMN tasks.task_interval; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tasks.task_interval IS 'Start interval (in seconds)';


--
-- Name: team_ldap_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_ldap_groups (
    team_id uuid NOT NULL,
    ldap_group character varying(1024) NOT NULL,
    team_role character varying(128) DEFAULT 'MEMBER'::character varying NOT NULL
);


ALTER TABLE public.team_ldap_groups OWNER TO postgres;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    team_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    team_name character varying(128) NOT NULL,
    description character varying(2048),
    org_id uuid DEFAULT '0fac1b18-d179-11e7-b3e7-d7df4543ed4f'::uuid NOT NULL
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: TABLE teams; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.teams IS 'User teams';


--
-- Name: template_aliases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.template_aliases (
    template_alias character varying(128) NOT NULL,
    template_url character varying(2048) NOT NULL
);


ALTER TABLE public.template_aliases OWNER TO postgres;

--
-- Name: trigger_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trigger_schedule (
    trigger_id uuid NOT NULL,
    fire_at timestamp with time zone NOT NULL
);


ALTER TABLE public.trigger_schedule OWNER TO postgres;

--
-- Name: triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.triggers (
    trigger_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    project_id uuid NOT NULL,
    repo_id uuid NOT NULL,
    event_source character varying(128) NOT NULL,
    arguments jsonb,
    conditions jsonb,
    active_profiles character varying[],
    trigger_cfg jsonb
);


ALTER TABLE public.triggers OWNER TO postgres;

--
-- Name: user_ldap_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_ldap_groups (
    user_id uuid NOT NULL,
    ldap_group character varying(1024) NOT NULL
);


ALTER TABLE public.user_ldap_groups OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid DEFAULT public.uuid_generate_v1() NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_teams (
    user_id uuid NOT NULL,
    team_id uuid NOT NULL,
    team_role character varying(128) DEFAULT 'MEMBER'::character varying NOT NULL
);


ALTER TABLE public.user_teams OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    username character varying(64) NOT NULL,
    display_name character varying(1024),
    user_type character varying(32) DEFAULT 'LDAP'::character varying NOT NULL,
    user_email character varying(512),
    is_disabled boolean DEFAULT false NOT NULL,
    last_group_sync_dt timestamp with time zone,
    domain character varying(512)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.users IS 'Users';


--
-- Name: COLUMN users.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.user_id IS 'Unique user ID';


--
-- Name: COLUMN users.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.username IS 'Unique name of a user (login)';


--
-- Name: COLUMN users.last_group_sync_dt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.last_group_sync_dt IS 'Timestamp of the last user group synchronization attempt';


--
-- Name: v_audit_log; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_audit_log AS
 SELECT a.entry_seq,
    a.entry_date,
    a.user_id,
    ( SELECT u.username
           FROM public.users u
          WHERE (u.user_id = a.user_id)) AS username,
    a.entry_object,
    a.entry_action,
    a.entry_details
   FROM public.audit_log a;


ALTER TABLE public.v_audit_log OWNER TO postgres;

--
-- Name: v_user_teams; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_user_teams AS
 SELECT user_teams.user_id,
    user_teams.team_id,
    user_teams.team_role
   FROM public.user_teams
UNION
 SELECT DISTINCT ulg.user_id,
    tlg.team_id,
    tlg.team_role
   FROM public.team_ldap_groups tlg,
    public.user_ldap_groups ulg
  WHERE (((ulg.ldap_group)::text = (tlg.ldap_group)::text) AND (NOT (EXISTS ( SELECT 1
           FROM public.user_teams ut
          WHERE ((ut.user_id = ulg.user_id) AND (ut.team_id = tlg.team_id))))));


ALTER TABLE public.v_user_teams OWNER TO postgres;

--
-- Name: audit_log entry_seq; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN entry_seq SET DEFAULT nextval('public.audit_log_entry_seq_seq'::regclass);


--
-- Name: node_roster_host_facts seq_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.node_roster_host_facts ALTER COLUMN seq_id SET DEFAULT nextval('public.node_roster_host_facts_seq_id_seq'::regclass);


--
-- Name: process_events event_seq; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_events ALTER COLUMN event_seq SET DEFAULT nextval('public.process_events_event_seq_seq'::regclass);


--
-- Name: process_log_data segment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_log_data ALTER COLUMN segment_id SET DEFAULT nextval('public.process_log_data_segment_id_seq'::regclass);


--
-- Name: process_log_data log_seq; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_log_data ALTER COLUMN log_seq SET DEFAULT nextval('public.process_log_data_log_seq_seq'::regclass);


--
-- Name: process_log_segments segment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_log_segments ALTER COLUMN segment_id SET DEFAULT nextval('public.process_log_segments_segment_id_seq'::regclass);


--
-- Name: process_queue id_seq; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_queue ALTER COLUMN id_seq SET DEFAULT nextval('public.process_queue_id_seq_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admins (user_id) FROM stdin;
230c5c9c-d9a7-11e6-bcfd-bb681c07b26c
\.


--
-- Data for Name: agent_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_commands (command_id, agent_id, command_status, created_at, command_data) FROM stdin;
\.


--
-- Data for Name: ansible_hosts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ansible_hosts (instance_id, instance_created_at, host, host_group, event_seq, status, duration, playbook_id) FROM stdin;
\.


--
-- Data for Name: ansible_play_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ansible_play_stats (instance_id, instance_created_at, playbook_id, play_id, play_name, play_order, host_count, task_count, finished_task_count) FROM stdin;
\.


--
-- Data for Name: ansible_playbook_result; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ansible_playbook_result (instance_id, instance_created_at, playbook_id, status) FROM stdin;
\.


--
-- Data for Name: ansible_playbook_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ansible_playbook_stats (instance_id, instance_created_at, playbook_id, name, started_at, host_count, play_count, total_work, retry_num) FROM stdin;
\.


--
-- Data for Name: ansible_task_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ansible_task_stats (instance_id, instance_created_at, playbook_id, play_id, task_id, task_name, task_order, task_type, ok_count, failed_count, unreachable_count, skipped_count, running_count) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (key_id, api_key, user_id, key_name, expired_at, last_notified_at) FROM stdin;
ea523cfc-7ca2-11eb-88f0-02420a800003	1sw9eLZ41EOK4w/iV3jFnn6cqeAMeFtxfazqVY04koY	d4f123c1-f8d4-40b2-8a12-b8947b9ce2d8	key-1	\N	\N
ea548d68-7ca2-11eb-88f0-02420a800003	DrRt3j6G7b6GHY/Prddu4voyKyZa17iFkEj99ac0q/A	2599c604-1384-4660-a767-8bc03baa7a31	key-1	\N	\N
eb2cdb82-7ca2-11eb-88f0-02420a800003	9/VilCHrW6gXO3ODZmhKOAAf9gHOtP/CZt6OHhBFRVs	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	autogenerated	\N	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (entry_date, user_id, entry_object, entry_action, entry_details, entry_seq) FROM stdin;
2021-03-31 02:40:13.613007+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	SYSTEM	ACCESS	{"realm": "apikey", "apiKeyId": "eb2cdb82-7ca2-11eb-88f0-02420a800003", "requestId": "e5a566f5-3a7b-4c1b-912e-e2501ce17305", "requestIp": "10.128.0.1", "actionSource": {"type": "UI"}}	20
2021-03-31 02:44:37.651725+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	JSON_STORE	CREATE	{"name": "TestStore", "orgId": "0fac1b18-d179-11e7-b3e7-d7df4543ed4f", "requestId": "6fb73a9f-a3d4-46b4-8fec-7a0a063fcc0d", "requestIp": "10.128.0.1", "jsonStoreId": "08c4c640-91cb-11eb-88c1-02420a800003", "actionSource": {"type": "UI"}}	21
2021-03-31 02:49:23.939256+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	SYSTEM	ACCESS	{"realm": "apikey", "apiKeyId": "eb2cdb82-7ca2-11eb-88f0-02420a800003", "requestId": "7d2f1cab-92eb-43b1-b4a6-62f95679a1a6", "requestIp": "10.128.0.1", "actionSource": {"type": "API_REQUEST"}}	22
2021-03-31 02:49:23.969669+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	JSON_STORE_DATA	CREATE	{"orgId": "0fac1b18-d179-11e7-b3e7-d7df4543ed4f", "itemPath": "service_a", "requestId": "7d2f1cab-92eb-43b1-b4a6-62f95679a1a6", "requestIp": "10.128.0.1", "jsonStoreId": "08c4c640-91cb-11eb-88c1-02420a800003", "actionSource": {"type": "API_REQUEST"}}	23
2021-03-31 02:49:24.001097+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	SYSTEM	ACCESS	{"realm": "apikey", "apiKeyId": "eb2cdb82-7ca2-11eb-88f0-02420a800003", "requestId": "8726d5df-b946-4855-9d62-373fd3efb4ab", "requestIp": "10.128.0.1", "actionSource": {"type": "API_REQUEST"}}	24
2021-03-31 02:49:24.039955+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	JSON_STORE_DATA	CREATE	{"orgId": "0fac1b18-d179-11e7-b3e7-d7df4543ed4f", "itemPath": "service_b", "requestId": "8726d5df-b946-4855-9d62-373fd3efb4ab", "requestIp": "10.128.0.1", "jsonStoreId": "08c4c640-91cb-11eb-88c1-02420a800003", "actionSource": {"type": "API_REQUEST"}}	25
2021-03-31 02:50:12.194705+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	SYSTEM	ACCESS	{"realm": "apikey", "apiKeyId": "eb2cdb82-7ca2-11eb-88f0-02420a800003", "requestId": "5bf3c4b7-8dee-47cc-9433-8b88524467db", "requestIp": "10.128.0.1", "actionSource": {"type": "API_REQUEST"}}	26
2021-03-31 02:50:12.222258+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	JSON_STORE_QUERY	CREATE	{"orgId": "0fac1b18-d179-11e7-b3e7-d7df4543ed4f", "changes": {"newQuery": "select item_data->service from json_store_data where item_data @> ?::jsonb"}, "queryName": "lookupServiceByUser", "requestId": "5bf3c4b7-8dee-47cc-9433-8b88524467db", "requestIp": "10.128.0.1", "jsonStoreId": "08c4c640-91cb-11eb-88c1-02420a800003", "actionSource": {"type": "API_REQUEST"}}	27
2021-03-31 02:51:24.516889+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	JSON_STORE	UPDATE	{"access": {"teams": [{"id": "00000000-0000-0000-0000-000000000000", "level": "OWNER"}], "replace": true}, "storeId": "08c4c640-91cb-11eb-88c1-02420a800003", "requestId": "c0b70ba7-a900-4965-9f2a-0732d6516afb", "requestIp": "10.128.0.1", "actionSource": {"type": "UI"}}	28
2021-03-31 02:52:52.326101+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	SYSTEM	ACCESS	{"realm": "apikey", "apiKeyId": "eb2cdb82-7ca2-11eb-88f0-02420a800003", "requestId": "cade7303-6583-4af5-8817-c1a6453d88e4", "requestIp": "10.128.0.1", "actionSource": {"type": "API_REQUEST"}}	29
2021-03-31 02:53:14.908902+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	JSON_STORE_QUERY	UPDATE	{"orgId": "0fac1b18-d179-11e7-b3e7-d7df4543ed4f", "changes": {"newQuery": "select item_data->'service' from json_store_data where item_data @> ?::jsonb", "prevQuery": "select item_data->service from json_store_data where item_data @> ?::jsonb"}, "queryName": "lookupServiceByUser", "requestId": "21002fac-071e-4436-889b-0cf600da8528", "requestIp": "10.128.0.1", "jsonStoreId": "08c4c640-91cb-11eb-88c1-02420a800003", "actionSource": {"type": "UI"}}	30
2021-03-31 02:53:17.09065+00	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	SYSTEM	ACCESS	{"realm": "apikey", "apiKeyId": "eb2cdb82-7ca2-11eb-88f0-02420a800003", "requestId": "fd9f4883-ffce-49d9-85b9-557275b4152a", "requestIp": "10.128.0.1", "actionSource": {"type": "API_REQUEST"}}	31
\.


--
-- Data for Name: event_processor_marker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_processor_marker (processor_name, event_seq) FROM stdin;
noderoster/ansible-events-processor	-1
ansible-event-processor	-1
\.


--
-- Data for Name: json_store_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.json_store_data (json_store_id, item_path, item_data, item_data_size) FROM stdin;
08c4c640-91cb-11eb-88c1-02420a800003	service_a	{"users": ["bob", "alice"], "service": "service_a"}	61
08c4c640-91cb-11eb-88c1-02420a800003	service_b	{"users": ["alice", "mike"], "service": "service_b"}	62
\.


--
-- Data for Name: json_store_queries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.json_store_queries (query_id, json_store_id, query_name, query_text) FROM stdin;
d0309eb6-91cb-11eb-b2b6-02420a800003	08c4c640-91cb-11eb-88c1-02420a800003	lookupServiceByUser	select item_data->'service' from json_store_data where item_data @> ?::jsonb
\.


--
-- Data for Name: json_store_team_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.json_store_team_access (json_store_id, team_id, access_level) FROM stdin;
08c4c640-91cb-11eb-88c1-02420a800003	00000000-0000-0000-0000-000000000000	OWNER
\.


--
-- Data for Name: json_stores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.json_stores (json_store_id, json_store_name, parent_inventory_id, org_id, visibility, owner_id) FROM stdin;
08c4c640-91cb-11eb-88c1-02420a800003	TestStore	\N	0fac1b18-d179-11e7-b3e7-d7df4543ed4f	PRIVATE	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c
\.


--
-- Data for Name: node_roster_host_artifacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.node_roster_host_artifacts (instance_id, instance_created_at, host_id, artifact_url) FROM stdin;
\.


--
-- Data for Name: node_roster_host_facts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.node_roster_host_facts (instance_id, instance_created_at, host_id, facts, seq_id) FROM stdin;
\.


--
-- Data for Name: node_roster_hosts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.node_roster_hosts (host_id, normalized_hostname, created_at) FROM stdin;
\.


--
-- Data for Name: node_roster_process_hosts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.node_roster_process_hosts (instance_id, instance_created_at, host_id, initiator, initiator_id, project_id) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (org_id, org_name, visibility, meta, org_cfg, owner_id) FROM stdin;
0fac1b18-d179-11e7-b3e7-d7df4543ed4f	Default	PUBLIC	\N	\N	\N
94a35e54-d204-11e7-9a97-c32b8f0c3380	ConcordSystem	PRIVATE	\N	\N	\N
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (permission_id, permission_name, description) FROM stdin;
1880f2aa-6abf-11e9-bfc0-93407d3c5df1	getProcessQueueAllOrgs	Read-only access to the process queue for all organizations
7833764b-eb62-4017-84aa-cd57d594836f	createOrg	Permission to create organizations
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.policies (policy_id, policy_name, rules, parent_policy_id) FROM stdin;
\.


--
-- Data for Name: policy_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.policy_links (org_id, project_id, policy_id, user_id) FROM stdin;
\.


--
-- Data for Name: process_checkpoints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_checkpoints (checkpoint_id, instance_id, checkpoint_data, checkpoint_name, checkpoint_date, instance_created_at) FROM stdin;
\.


--
-- Data for Name: process_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_events (instance_id, event_type, event_date, event_data, event_id, event_seq, instance_created_at) FROM stdin;
\.


--
-- Data for Name: process_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_locks (instance_id, org_id, project_id, lock_scope, lock_name) FROM stdin;
\.


--
-- Data for Name: process_log_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_log_data (instance_id, instance_created_at, segment_id, log_range, segment_range, chunk_data, log_seq) FROM stdin;
\.


--
-- Data for Name: process_log_segments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_log_segments (instance_id, instance_created_at, segment_id, segment_name, correlation_id, segment_ts, segment_status, segment_errors, segment_warn) FROM stdin;
\.


--
-- Data for Name: process_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_queue (instance_id, created_at, current_status, last_agent_id, last_updated_at, parent_instance_id, process_kind, process_tags, project_id, start_at, requirements, repo_id, repo_url, repo_path, commit_id, commit_msg, initiator_id, meta, timeout, handlers, last_run_at, wait_conditions, is_disabled, imports, triggered_by, exclusive, runtime, id_seq, dependencies, commit_branch, suspend_timeout) FROM stdin;
\.


--
-- Data for Name: process_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.process_state (instance_id, item_path, item_data, unix_mode, is_encrypted, instance_created_at) FROM stdin;
\.


--
-- Data for Name: project_kv_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_kv_store (value_key, value_long, value_string, project_id) FROM stdin;
\.


--
-- Data for Name: project_team_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_team_access (project_id, team_id, access_level) FROM stdin;
1afd0382-7ca3-11eb-88f0-02420a800003	00000000-0000-0000-0000-000000000000	OWNER
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (project_name, description, project_cfg, project_id, visibility, org_id, owner_id, secret_key, meta, raw_payload_mode, out_variables_mode) FROM stdin;
concordTriggers	\N	\N	ad76f1e2-c33c-11e7-8064-f7371c66fa77	PUBLIC	94a35e54-d204-11e7-9a97-c32b8f0c3380	\N	\N	\N	DISABLED	DISABLED
Test	Test Project	\N	1afd0382-7ca3-11eb-88f0-02420a800003	PUBLIC	0fac1b18-d179-11e7-b3e7-d7df4543ed4f	230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	\\xe809e98a5a03e76341c20321d1bf9e95221b1f5a161620b6e43d8d88f06d20ec4fee6b2b3ad7387f73d8134413a29dbbcfacc6953bd3db01903259aadea77e1bf1510fb703507cb9f593a198b5f28fefe1e6fe60f9cab42b88c813b3802d4140d681a117e112377e1afcc7bdd2e92796667f53166042769391a8aa54797099fabef130c025c078a740f09c8b9730193c	\N	TEAM_MEMBERS	DISABLED
\.


--
-- Data for Name: repositories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.repositories (repo_name, repo_url, repo_branch, repo_commit_id, repo_path, project_id, repo_id, secret_id, webhook_id, meta, is_disabled) FROM stdin;
triggers	classpath://com/walmartlabs/concord/server/org/triggers/concord.yml	master	\N	\N	ad76f1e2-c33c-11e7-8064-f7371c66fa77	b31b0b06-c33c-11e7-b0e9-8702fc03629f	\N	\N	\N	f
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
eabcd922-7ca2-11eb-88f0-02420a800003	7833764b-eb62-4017-84aa-cd57d594836f
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_id, role_name, global_reader, global_writer) FROM stdin;
21d646b2-6a9c-11e8-acce-d37cf888abd9	concordSystemReader	t	f
c162d868-89ea-11e8-80be-97fd8a9f7419	concordSystemWriter	f	t
eabcd922-7ca2-11eb-88f0-02420a800003	concordAdmin	f	f
\.


--
-- Data for Name: secret_team_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.secret_team_access (secret_id, team_id, access_level) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.secrets (secret_name, secret_type, secret_data, encrypted_by, secret_id, org_id, owner_id, visibility, store_type, project_id) FROM stdin;
\.


--
-- Data for Name: server_db_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.server_db_lock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: server_db_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.server_db_log (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.605705	1	EXECUTED	7:3d89452a6c9e4909a73492104cd83dea	createTable tableName=USERS		\N	3.5.1	\N	\N	4832469142
1210	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.632435	2	EXECUTED	7:76d1c194deaabe7f36e25a41014c6b0d	insert tableName=USERS		\N	3.5.1	\N	\N	4832469142
1400	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.651636	3	EXECUTED	7:bb26a4d87f7950a038c5fa3618494b48	createTable tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
1410	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.66702	4	EXECUTED	7:b5f2a986ec7895fbef1f33361bf17966	createIndex indexName=IDX_API_KEY, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
1420	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.680073	5	EXECUTED	7:eb5d014b60651c38c5d832eea0f473e4	addForeignKeyConstraint baseTableName=API_KEYS, constraintName=FK_API_KEY_USER, referencedTableName=USERS		\N	3.5.1	\N	\N	4832469142
1430	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.68894	6	EXECUTED	7:21083bfe5c816a6d9ba45bbf064bad52	createIndex indexName=IDX_API_KEY_USER, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
1440	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.695918	7	EXECUTED	7:548887fbdf1b3155c8492f7f27a9f37f	insert tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
1500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.717585	8	EXECUTED	7:a9c6beedd779af780cc8045ebf515bb9	createTable tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
1600	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.734127	9	EXECUTED	7:d0f68ab04d71b508c187ad949408b534	createTable tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
1700	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.757601	10	EXECUTED	7:1a47fbf33b2b52bcab0ac64cd27b1cba	createTable tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
1720	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.770075	11	EXECUTED	7:e8f72d84997a7abfa48f00c8b9919913	addForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_REPOS_PROJECT, referencedTableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
1730	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.0.1.xml	2021-03-04 04:34:29.780427	12	EXECUTED	7:425f4ebc33be25b5c6d3eceb683ea123	addForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_REPOS_SECRET, referencedTableName=SECRETS		\N	3.5.1	\N	\N	4832469142
13000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.13.0.xml	2021-03-04 04:34:29.796337	13	EXECUTED	7:340cb0999c0f2917b2bab015cdcd04dc	createTable tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
13100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.13.0.xml	2021-03-04 04:34:29.809243	14	EXECUTED	7:58827ff5eb710c47ec93a65c32ea829f	addColumn tableName=USERS		\N	3.5.1	\N	\N	4832469142
14000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.14.0.xml	2021-03-04 04:34:29.819056	15	EXECUTED	7:c790dbe85e6257b8447af4a95c2d52c6	createIndex indexName=IDX_PROC_Q_POLL, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
14100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.14.0.xml	2021-03-04 04:34:29.830658	16	EXECUTED	7:a855ec88d569c0cb05cd129c1c5735f7	createIndex indexName=IDX_PROC_Q_CR_AT, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
17000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.17.0.xml	2021-03-04 04:34:29.850219	17	EXECUTED	7:1f660db30bf13f68d32b69dfcf258b12	addColumn tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
17500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.17.0.xml	2021-03-04 04:34:29.865121	18	EXECUTED	7:aa57b040eaa0cb51d24a1c741ac7c34f	addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
17900	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.17.0.xml	2021-03-04 04:34:29.938658	19	EXECUTED	7:625068699f3686cb7994addb78321076	createTable tableName=PROJECT_KV_STORE		\N	3.5.1	\N	\N	4832469142
18000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.18.0.xml	2021-03-04 04:34:29.955436	20	EXECUTED	7:df2c5f86dc6836bf48def6c26bbcb89b	addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
18010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.18.0.xml	2021-03-04 04:34:30.027077	21	MARK_RAN	7:12df905c7e911609576651b0b9810eac	sql	Migrate project configuration from the attachments table to the main table.	\N	3.5.1	\N	\N	4832469142
20000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.20.0.xml	2021-03-04 04:34:30.04969	22	EXECUTED	7:b3d65d57ff394117447433f1912ce0ec	createTable tableName=PROCESS_STATE		\N	3.5.1	\N	\N	4832469142
21000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.21.0.xml	2021-03-04 04:34:30.07106	23	EXECUTED	7:22252741acccaa6cf9df497b1b00ba74	createTable tableName=AGENT_COMMANDS		\N	3.5.1	\N	\N	4832469142
22000	brig@gmail.com	com/walmartlabs/concord/server/db/v0.22.0.xml	2021-03-04 04:34:30.089673	24	EXECUTED	7:71796d2c90b47f979912b1cc261c2951	createTable tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
23000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.23.0.xml	2021-03-04 04:34:30.115716	25	EXECUTED	7:7aecdc6107f614d6e960d5e9f6e19781	createTable tableName=TEMPLATE_ALIASES		\N	3.5.1	\N	\N	4832469142
27000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.27.0.xml	2021-03-04 04:34:30.139072	26	EXECUTED	7:de5188149b9ae2c6a6dabd7ccae6c2f9	sql		\N	3.5.1	\N	\N	4832469142
31000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.184694	27	EXECUTED	7:45c3009a7cfc4ce5254031057dc18202	dropForeignKeyConstraint baseTableName=API_KEYS, constraintName=FK_API_KEY_USER		\N	3.5.1	\N	\N	4832469142
31010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.278733	28	EXECUTED	7:cbc97e3f58c64e8359f706ba26eae73c	modifyDataType columnName=USER_ID, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
31040	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.311195	29	EXECUTED	7:a0450d04af6c4249197ee0e9aff725e8	modifyDataType columnName=USER_ID, tableName=USERS		\N	3.5.1	\N	\N	4832469142
31050	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.338374	30	EXECUTED	7:eb5d014b60651c38c5d832eea0f473e4	addForeignKeyConstraint baseTableName=API_KEYS, constraintName=FK_API_KEY_USER, referencedTableName=USERS		\N	3.5.1	\N	\N	4832469142
31070	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.402578	31	EXECUTED	7:18ee09f29608bd63b5708d8bd12a2cb3	modifyDataType columnName=KEY_ID, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
31120	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.449298	32	EXECUTED	7:268b8e5dd4954e99eea44026c49ad230	modifyDataType columnName=INSTANCE_ID, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
31130	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.480688	33	EXECUTED	7:b8744a2d34b0c0e4375a2262f8ed0dbf	modifyDataType columnName=INSTANCE_ID, tableName=PROCESS_STATE		\N	3.5.1	\N	\N	4832469142
31140	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.503013	34	EXECUTED	7:f95f0f850976e158bf58a0746403d0c9	modifyDataType columnName=COMMAND_ID, tableName=AGENT_COMMANDS		\N	3.5.1	\N	\N	4832469142
31150	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.31.0.xml	2021-03-04 04:34:30.520006	35	EXECUTED	7:50b4f8c4a5f747a7de5e01aa74b71b33	modifyDataType columnName=INSTANCE_ID, tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
38000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.38.0.xml	2021-03-04 04:34:30.527698	36	EXECUTED	7:ef18642b250fa2b34047a7838c3be188	addColumn tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
39000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.39.0.xml	2021-03-04 04:34:30.556841	37	EXECUTED	7:30c40a79566a5aafcecd49e9aa6e4c4c	addColumn tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
39100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.39.0.xml	2021-03-04 04:34:30.57072	38	EXECUTED	7:08aeb0f7e15b96a027413cd3be2b87f5	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
39110	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.39.0.xml	2021-03-04 04:34:30.58445	39	EXECUTED	7:5c614f6456168704931dd44df5c61e55	createIndex indexName=IDX_PROC_Q_PAR_ID, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
41000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.41.0.xml	2021-03-04 04:34:30.591928	40	EXECUTED	7:59b80a374021147043d0c15ffebac8f2	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
44000-init	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.606984	41	EXECUTED	7:19b9f75dbeb4f4969f1d59c7643fc723	sql		\N	3.5.1	\N	\N	4832469142
44000-cleanup	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.629127	42	EXECUTED	7:fe05d00e98c1ccc48a1c1124ebf513f3	sql; sql		\N	3.5.1	\N	\N	4832469142
44000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.665167	43	EXECUTED	7:c18c42d60ff0ea2bfb5146eafb12905e	addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
44010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.693228	44	EXECUTED	7:a1ea2897db9cd2ee0fb42d0ebc5746d3	addColumn tableName=REPOSITORIES; sql; addNotNullConstraint columnName=PROJECT_ID, tableName=REPOSITORIES; dropColumn tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
44020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.704705	45	EXECUTED	7:5a675aa50246fbbb79cec2b7f81af758	addColumn tableName=PROCESS_QUEUE; sql; dropColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
44030	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.738875	46	EXECUTED	7:59727d852889ef586009da92b41a4c71	addColumn tableName=PROJECT_KV_STORE; sql; dropColumn tableName=PROJECT_KV_STORE; addPrimaryKey constraintName=PK_PROJECT_KV, tableName=PROJECT_KV_STORE		\N	3.5.1	\N	\N	4832469142
44050	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.764692	47	EXECUTED	7:511eee9dc4387294f8da148079f4f178	sql; dropPrimaryKey tableName=PROJECTS; addPrimaryKey constraintName=PK_PROJECTS, tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
44060	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.779513	48	EXECUTED	7:fc18c1c8a98d102818018cba33f9235b	addUniqueConstraint tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
44100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.814959	49	EXECUTED	7:91ac80cfe2c1a11d0b91763e57f859d1	addColumn tableName=REPOSITORIES; addPrimaryKey constraintName=PK_REPOSITORIES, tableName=REPOSITORIES; sql; addUniqueConstraint tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
44200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.836241	50	EXECUTED	7:ee07519106a378df9750035474ed58ca	addColumn tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
44210	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.857442	51	EXECUTED	7:5ecbcc68c29731d2f1632ba876e440d9	addColumn tableName=REPOSITORIES; sql; dropColumn tableName=REPOSITORIES; addUniqueConstraint tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
44220	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.874738	52	EXECUTED	7:584cd764b89bce0cb558e9b090a2e19b	sql; dropPrimaryKey tableName=SECRETS; addPrimaryKey constraintName=PK_SECRETS, tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
44300	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.886991	53	EXECUTED	7:74e0b3919e0c0456985b0e1fd775cf03	addForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_RP_SCR_ID, referencedTableName=SECRETS		\N	3.5.1	\N	\N	4832469142
44310	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.895408	54	EXECUTED	7:6c1e9fe09eeac41aab38b96824aad5fb	addForeignKeyConstraint baseTableName=PROCESS_QUEUE, constraintName=FK_PQ_RPJ_ID, referencedTableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
44320	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.903741	55	EXECUTED	7:4fdf320e3c0772a4906087644eb89504	addForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_REPO_RPJ_ID, referencedTableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
44500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.44.0.xml	2021-03-04 04:34:30.921898	56	EXECUTED	7:1d2c02ad90579ae54d90aba0c90353bb	addColumn tableName=PROCESS_STATE		\N	3.5.1	\N	\N	4832469142
45000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:30.942631	57	EXECUTED	7:bcfa7d5880d47a4ff8975b58e7448775	createTable tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
45010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:30.949292	58	EXECUTED	7:de0a351cecdf2475885e7b2b19196e4b	insert tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
45020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:30.969871	59	EXECUTED	7:731714f5c34a448086d66b5fa70d48d4	addColumn tableName=PROJECTS; addForeignKeyConstraint baseTableName=PROJECTS, constraintName=FK_PRJ_TEAM_ID, referencedTableName=TEAMS		\N	3.5.1	\N	\N	4832469142
45030	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:30.994243	60	EXECUTED	7:cabd780e82d1cc0c11f179cde63a4503	addColumn tableName=SECRETS; addForeignKeyConstraint baseTableName=SECRETS, constraintName=FK_PRJ_TEAM_ID, referencedTableName=TEAMS		\N	3.5.1	\N	\N	4832469142
45040	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.018935	61	EXECUTED	7:f831b6c21946672633244fb8b82cc9e8	createTable tableName=USER_TEAMS; addForeignKeyConstraint baseTableName=USER_TEAMS, constraintName=FK_USR_TEAMS_USR, referencedTableName=USERS; addForeignKeyConstraint baseTableName=USER_TEAMS, constraintName=FK_USR_TEAMS_TEAM, referencedTableName...		\N	3.5.1	\N	\N	4832469142
45500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.026734	62	EXECUTED	7:6decd76340a2151348be3b1a04921aa9	addDefaultValue columnName=USER_ID, tableName=USERS		\N	3.5.1	\N	\N	4832469142
45600	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.034844	63	EXECUTED	7:60b556d2c242e6e560026a39225207d4	addDefaultValue columnName=KEY_ID, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
45700	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.058391	64	EXECUTED	7:79be75fa230d57cf631d0d5fd37c6f5c	createTable tableName=INVENTORIES		\N	3.5.1	\N	\N	4832469142
48120	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.637849	92	EXECUTED	7:8d93a51e32a05b48e03de3027f2eddd1	sql; sql		\N	3.5.1	\N	\N	4832469142
45701	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.102087	65	EXECUTED	7:a9390ec5811161be574e8469587dc64b	addForeignKeyConstraint baseTableName=INVENTORIES, constraintName=FK_INVENTORIES_PARENT, referencedTableName=INVENTORIES; addForeignKeyConstraint baseTableName=INVENTORIES, constraintName=FK_INVENTORIES_TEAMS, referencedTableName=TEAMS		\N	3.5.1	\N	\N	4832469142
45702	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.129778	66	EXECUTED	7:6b73100bbd445dbc706648a4118b6070	createTable tableName=INVENTORY_DATA		\N	3.5.1	\N	\N	4832469142
45703	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.138554	67	EXECUTED	7:56a41a2a2759f6c04172df0688c7e138	addForeignKeyConstraint baseTableName=INVENTORY_DATA, constraintName=FK_INVENTORY_DATA_INVENTORY, referencedTableName=INVENTORIES		\N	3.5.1	\N	\N	4832469142
45704	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.15802	68	EXECUTED	7:c01ff799d6c56044504c649015a70f70	createTable tableName=INVENTORY_QUERIES		\N	3.5.1	\N	\N	4832469142
45705	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.45.0.xml	2021-03-04 04:34:31.177282	69	EXECUTED	7:0b094bbd03a24601a9737e2245003119	addForeignKeyConstraint baseTableName=INVENTORY_QUERIES, constraintName=FK_INVENTORY_QUERIES_INVENTORY, referencedTableName=INVENTORIES; addUniqueConstraint constraintName=UNQ_INVENTORY_QUERIES, tableName=INVENTORY_QUERIES		\N	3.5.1	\N	\N	4832469142
46000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.46.0.xml	2021-03-04 04:34:31.198399	70	EXECUTED	7:f00fe32c6bf80f5e9bf73e06ffd21a59	addColumn tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
46010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.46.0.xml	2021-03-04 04:34:31.226036	71	EXECUTED	7:58073009af672f85e12f3dbf82448fce	dropPrimaryKey tableName=USER_TEAMS; addColumn tableName=USER_TEAMS; addPrimaryKey tableName=USER_TEAMS; sql		\N	3.5.1	\N	\N	4832469142
46020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.46.0.xml	2021-03-04 04:34:31.269445	72	EXECUTED	7:83eb438016e14268d4b19a41a8cd49ad	createTable tableName=ADMINS; addForeignKeyConstraint baseTableName=ADMINS, constraintName=FK_ADMINS_U_ID, referencedTableName=USERS; sql		\N	3.5.1	\N	\N	4832469142
46100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.46.0.xml	2021-03-04 04:34:31.290435	73	EXECUTED	7:712593de504c8a9bb1d909d59dd36e80	addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
47000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.311719	74	EXECUTED	7:973fa12437ad6222511356ae6d091f8e	createTable tableName=TRIGGERS; addForeignKeyConstraint baseTableName=TRIGGERS, constraintName=FK_TRIGGERS_PROJECT_ID, referencedTableName=PROJECTS; addForeignKeyConstraint baseTableName=TRIGGERS, constraintName=FK_TRIGGERS_REPO_ID, referencedTabl...		\N	3.5.1	\N	\N	4832469142
47010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.320996	75	EXECUTED	7:6d5f1f48a45728b28266496124e9ce60	createIndex indexName=IDX_TRIG_EV_SRC, tableName=TRIGGERS		\N	3.5.1	\N	\N	4832469142
47100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.340009	76	EXECUTED	7:78f615f4e79fdbbc7ba6f509e060ec23	insert tableName=TEAMS; insert tableName=PROJECTS; insert tableName=REPOSITORIES; insert tableName=TRIGGERS; insert tableName=TRIGGERS		\N	3.5.1	\N	\N	4832469142
47200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.363261	77	EXECUTED	7:dc48d511d4a571298dfba6ef0ba500ca	sql; addUniqueConstraint tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
47500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.379091	78	EXECUTED	7:e255eee784209986bbcc99478e91aaac	sql		\N	3.5.1	\N	\N	4832469142
47600	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.391836	79	EXECUTED	7:13157194a8de7563f7836a566dcc9dfe	insert tableName=USERS; insert tableName=USER_TEAMS		\N	3.5.1	\N	\N	4832469142
47900	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.47.0.xml	2021-03-04 04:34:31.407101	80	EXECUTED	7:8a6ef8916144eee921eeb98020f5d0c2	dropUniqueConstraint constraintName=PROJECTS_PROJECT_NAME_KEY, tableName=PROJECTS; addUniqueConstraint tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
48000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.44608	81	EXECUTED	7:394e34a0e7fb3e68afa82d8fafafd3ae	createTable tableName=ORGANIZATIONS; insert tableName=ORGANIZATIONS; insert tableName=ORGANIZATIONS		\N	3.5.1	\N	\N	4832469142
48010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.466583	82	EXECUTED	7:dce47d97879d033f17b019a1031c2984	addColumn tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
48020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.49121	83	EXECUTED	7:d7e7569d898c7660ab1272c87c42eb41	dropColumn columnName=TEAM_ID, tableName=PROJECTS; addColumn tableName=PROJECTS; addForeignKeyConstraint baseTableName=PROJECTS, constraintName=FK_PRJ_ORG_ID, referencedTableName=ORGANIZATIONS		\N	3.5.1	\N	\N	4832469142
48030	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.511962	84	EXECUTED	7:524f089953beba9bc5f3e8111707af9e	dropColumn columnName=TEAM_ID, tableName=SECRETS; addColumn tableName=SECRETS; addForeignKeyConstraint baseTableName=SECRETS, constraintName=FK_SECRET_ORG_ID, referencedTableName=ORGANIZATIONS		\N	3.5.1	\N	\N	4832469142
48040	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.530024	85	EXECUTED	7:7e4f48c31343b0562720888b6d35a4fc	dropColumn columnName=TEAM_ID, tableName=INVENTORIES; addColumn tableName=INVENTORIES; addForeignKeyConstraint baseTableName=INVENTORIES, constraintName=FK_INV_ORG_ID, referencedTableName=ORGANIZATIONS		\N	3.5.1	\N	\N	4832469142
48050	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.536633	86	EXECUTED	7:cbc12acd77d4427e27d290019be80e25	dropColumn columnName=VISIBILITY, tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
48060	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.549232	87	EXECUTED	7:aae467b9ad895875967412d5a63bcc54	dropUniqueConstraint constraintName=TEAMS_TEAM_NAME_KEY, tableName=TEAMS; addUniqueConstraint tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
48070	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.5563	88	EXECUTED	7:689b80f7e6b0152f749d216437b62725	dropColumn columnName=IS_ACTIVE, tableName=TEAMS		\N	3.5.1	\N	\N	4832469142
48090	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.59421	89	EXECUTED	7:aa97b8520d7e873c5420748445feecc4	createTable tableName=PROJECT_TEAM_ACCESS; addForeignKeyConstraint baseTableName=PROJECT_TEAM_ACCESS, constraintName=FK_PRJ_T_A_PRJ, referencedTableName=PROJECTS; addForeignKeyConstraint baseTableName=PROJECT_TEAM_ACCESS, constraintName=FK_PRJ_T_A...		\N	3.5.1	\N	\N	4832469142
48100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.615784	90	EXECUTED	7:a1d2a4f58a82519e1edc97dd827fc6c8	addColumn tableName=PROJECTS; addForeignKeyConstraint baseTableName=PROJECTS, constraintName=FK_PRJ_OWN_ID, referencedTableName=USERS; addUniqueConstraint tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
48110	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.629808	91	EXECUTED	7:13a5bede27e2d98282eedbf02e2c5253	sql		\N	3.5.1	\N	\N	4832469142
48130	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.647727	93	EXECUTED	7:33f841a9f68c06c96a765dee83ec7dee	addColumn tableName=SECRETS; addForeignKeyConstraint baseTableName=SECRETS, constraintName=FK_SCRT_OWN_ID, referencedTableName=USERS		\N	3.5.1	\N	\N	4832469142
48140	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.668166	94	EXECUTED	7:83b8d756036ccf3614331099393af3b2	createTable tableName=SECRET_TEAM_ACCESS; addForeignKeyConstraint baseTableName=SECRET_TEAM_ACCESS, constraintName=FK_SCRT_T_A_SCRT, referencedTableName=SECRETS; addForeignKeyConstraint baseTableName=SECRET_TEAM_ACCESS, constraintName=FK_SCRT_T_A_...		\N	3.5.1	\N	\N	4832469142
48150	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.685535	95	EXECUTED	7:4e8d47d69dc367d5a63ea24b036e7a9e	addColumn tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
48300	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.69071	96	EXECUTED	7:5497a09f89e07118bae806e66d17c388	update tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
48301	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.70558	97	EXECUTED	7:c398995701c8bafea9a076a048babe43	addColumn tableName=INVENTORIES		\N	3.5.1	\N	\N	4832469142
48302	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.720793	98	EXECUTED	7:48c9169b0ea0c34444ddcccf621bc00f	dropUniqueConstraint constraintName=INVENTORIES_INVENTORY_NAME_KEY, tableName=INVENTORIES; addUniqueConstraint tableName=INVENTORIES; addColumn tableName=INVENTORIES; addForeignKeyConstraint baseTableName=INVENTORIES, constraintName=FK_INVENTORIES...		\N	3.5.1	\N	\N	4832469142
48303	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.736851	99	EXECUTED	7:a6638c018d8645a8f8e564f6ee5584fc	createTable tableName=INVENTORY_TEAM_ACCESS; addForeignKeyConstraint baseTableName=INVENTORY_TEAM_ACCESS, constraintName=FK_INV_T_A_INV, referencedTableName=INVENTORIES; addForeignKeyConstraint baseTableName=INVENTORY_TEAM_ACCESS, constraintName=F...		\N	3.5.1	\N	\N	4832469142
48500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.743491	100	EXECUTED	7:cb0be3bc03ff38efaf0a26f793eafc13	sql		\N	3.5.1	\N	\N	4832469142
48600	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.753119	101	EXECUTED	7:93bea2b14640c43b8771573933059d64	dropForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_REPO_RPJ_ID; addForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_REPO_PRJ_ID, referencedTableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
48700	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.48.0.xml	2021-03-04 04:34:31.758264	102	EXECUTED	7:51b71a08bb197699ade0935096a489f2	addColumn tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
56000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.56.0.xml	2021-03-04 04:34:31.778138	103	EXECUTED	7:488f480e97731eb5c92838f08ce8bf7c	addColumn tableName=USERS; sql		\N	3.5.1	\N	\N	4832469142
58000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.58.0.xml	2021-03-04 04:34:31.786741	104	EXECUTED	7:96ff5c9c35d01bd79c9f377998c3a734	sql; sql		\N	3.5.1	\N	\N	4832469142
59000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.59.0.xml	2021-03-04 04:34:31.794737	105	EXECUTED	7:b5834d1d087abb2a64cabe8c91a36687	dropForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_RP_SCR_ID; addForeignKeyConstraint baseTableName=REPOSITORIES, constraintName=FK_RP_SCR_ID, referencedTableName=SECRETS		\N	3.5.1	\N	\N	4832469142
59100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.59.0.xml	2021-03-04 04:34:31.805875	106	EXECUTED	7:d619bf7df1e7f517fc39b546ed8365df	addColumn tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
59110	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.59.0.xml	2021-03-04 04:34:31.815181	107	EXECUTED	7:3683b4c3a83584e90d2a4be3c83d9c4e	createIndex indexName=IDX_PROC_EV_I_ID_DT, tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
60000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.60.0.xml	2021-03-04 04:34:31.820457	108	EXECUTED	7:e751b8189fd8a0e2c68df0e6b5d07c56	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
61200	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.61.0.xml	2021-03-04 04:34:31.832632	109	EXECUTED	7:9f01ae006d3c1ff05d2a22c1e732317e	createTable tableName=POLICIES		\N	3.5.1	\N	\N	4832469142
61201	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.61.0.xml	2021-03-04 04:34:31.850368	110	EXECUTED	7:fec532a813685d751a76dc7332e02893	createTable tableName=POLICY_LINKS; addForeignKeyConstraint baseTableName=POLICY_LINKS, constraintName=FK_POLICY_LINK_REPO_ID, referencedTableName=ORGANIZATIONS; addForeignKeyConstraint baseTableName=POLICY_LINKS, constraintName=FK_POLICY_LINK_PRO...		\N	3.5.1	\N	\N	4832469142
61202	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.61.0.xml	2021-03-04 04:34:31.884877	111	EXECUTED	7:463391787d4f8ea1fb31323c1eb3332f	createIndex indexName=IDX_POLICY_LINK_1, tableName=POLICY_LINKS		\N	3.5.1	\N	\N	4832469142
61203	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.61.0.xml	2021-03-04 04:34:31.927775	112	EXECUTED	7:75504223fbe3479fa8be155b67933c9e	createIndex indexName=IDX_POLICY_LINK_2, tableName=POLICY_LINKS		\N	3.5.1	\N	\N	4832469142
61204	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.61.0.xml	2021-03-04 04:34:31.94002	113	EXECUTED	7:bf505719362238917a7ba56d3cc44d48	createIndex indexName=IDX_POLICY_LINK_3, tableName=POLICY_LINKS		\N	3.5.1	\N	\N	4832469142
61205	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.61.0.xml	2021-03-04 04:34:31.953667	114	EXECUTED	7:a8d27d98c90a534e9088ce61bb2f49ec	createIndex indexName=IDX_POLICY_LINK_4, tableName=POLICY_LINKS		\N	3.5.1	\N	\N	4832469142
64000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.64.0.xml	2021-03-04 04:34:31.977238	115	EXECUTED	7:b7f372bd69bcf8af4160de2cd6ba2aeb	renameColumn newColumnName=ENCRYPTED_BY, oldColumnName=SECRET_STORE_TYPE, tableName=SECRETS; addColumn tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
64001	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.64.0.xml	2021-03-04 04:34:31.991459	116	EXECUTED	7:a9955e1ace35a8d94d4199d8042d6169	dropNotNullConstraint columnName=SECRET_DATA, tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
64100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.64.0.xml	2021-03-04 04:34:32.017232	117	EXECUTED	7:eb7a59ff4eca3ad84d143639e1a5e7f9	createTable tableName=AUDIT_LOG		\N	3.5.1	\N	\N	4832469142
64101	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.64.0.xml	2021-03-04 04:34:32.032735	118	EXECUTED	7:59f6227fdd6fcafe8254ebae699d01ef	createView viewName=V_AUDIT_LOG		\N	3.5.1	\N	\N	4832469142
64200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.64.0.xml	2021-03-04 04:34:32.051924	119	EXECUTED	7:eb8b6a13fba078b1731e7797fa1bc954	addUniqueConstraint tableName=POLICIES		\N	3.5.1	\N	\N	4832469142
64300	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.64.0.xml	2021-03-04 04:34:32.068741	120	EXECUTED	7:54300abd325c128df79a2b325157d9b3	addColumn tableName=ORGANIZATIONS		\N	3.5.1	\N	\N	4832469142
65000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.65.0.xml	2021-03-04 04:34:32.083127	121	EXECUTED	7:582fb01f35ad916be9b10b6cfc684fef	createTable tableName=TRIGGER_SCHEDULE; addForeignKeyConstraint baseTableName=TRIGGER_SCHEDULE, constraintName=FK_TRIGGER_SCHEDULE_TR_ID, referencedTableName=TRIGGERS		\N	3.5.1	\N	\N	4832469142
65010	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.65.0.xml	2021-03-04 04:34:32.091022	122	EXECUTED	7:b404eef34a8788610d325fd378719331	insert tableName=USERS		\N	3.5.1	\N	\N	4832469142
65020	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.65.0.xml	2021-03-04 04:34:32.101762	123	EXECUTED	7:4a7b3d4c8ffda639a5553b7e4185757b	createIndex indexName=IDX_TRIGGER_SCHED_FIRE_DATE, tableName=TRIGGER_SCHEDULE		\N	3.5.1	\N	\N	4832469142
66000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.66.0.xml	2021-03-04 04:34:32.114895	124	EXECUTED	7:9525331514c6f30b54bb439dfe749cc3	addUniqueConstraint tableName=SECRETS		\N	3.5.1	\N	\N	4832469142
67100	matthew.kunkel@walmartlabs.com	com/walmartlabs/concord/server/db/v0.67.0.xml	2021-03-04 04:34:32.150676	125	EXECUTED	7:b4f3446d4438acc4201a76cf9ab37959	addColumn tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
67200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.67.0.xml	2021-03-04 04:34:32.265652	126	EXECUTED	7:148f09276f67cb16502d0df0b9f4796c	addColumn tableName=AUDIT_LOG; createView viewName=V_AUDIT_LOG; dropColumn tableName=AUDIT_LOG; addPrimaryKey tableName=AUDIT_LOG		\N	3.5.1	\N	\N	4832469142
69000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.69.0.xml	2021-03-04 04:34:32.279606	127	EXECUTED	7:24e10d0f17eb124b478e2b8a75ffe0e3	insert tableName=USERS; insert tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
70000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.70.0.xml	2021-03-04 04:34:32.301973	128	EXECUTED	7:f8a0d4136ba8b18d8e1f3ffbffe53a41	insert tableName=USERS; insert tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
70100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.70.0.xml	2021-03-04 04:34:32.312034	129	EXECUTED	7:7e6a1d90283054ef7e6bcf3b6461eb14	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
71500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.71.0.xml	2021-03-04 04:34:32.348431	130	EXECUTED	7:63f602b404c6616f3716a010eeb3c396	dropPrimaryKey tableName=USER_TEAMS; addPrimaryKey tableName=USER_TEAMS		\N	3.5.1	\N	\N	4832469142
74000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.74.0.xml	2021-03-04 04:34:32.37588	131	EXECUTED	7:dfd6eafe181fd98dde24ab001ca0cf86	createTable tableName=ROLES		\N	3.5.1	\N	\N	4832469142
74010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.74.0.xml	2021-03-04 04:34:32.414241	132	EXECUTED	7:96aa544de7ed1c63927a146c6076da7b	createTable tableName=USER_ROLES; addForeignKeyConstraint baseTableName=USER_ROLES, constraintName=FK_U_R_USER, referencedTableName=USERS; addForeignKeyConstraint baseTableName=USER_ROLES, constraintName=FK_U_R_ROLE, referencedTableName=ROLES		\N	3.5.1	\N	\N	4832469142
74020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.74.0.xml	2021-03-04 04:34:32.437741	133	EXECUTED	7:782713982498d7c0497f5be9380e892a	insert tableName=ROLES; insert tableName=USER_ROLES; insert tableName=USER_ROLES		\N	3.5.1	\N	\N	4832469142
77000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.77.0.xml	2021-03-04 04:34:32.482085	134	EXECUTED	7:7ec54cd99e965e1d793c74f1cc7ec4b0	addColumn tableName=SECRETS; addForeignKeyConstraint baseTableName=SECRETS, constraintName=FK_PRJ_ID_SECRETS, referencedTableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
79000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.79.0.xml	2021-03-04 04:34:32.488777	135	EXECUTED	7:c84d0820eb9357be47be4b70c92d8298	insert tableName=USER_ROLES		\N	3.5.1	\N	\N	4832469142
79100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.79.0.xml	2021-03-04 04:34:32.534291	136	EXECUTED	7:1c3a84f78753b660a0ec34b0a3ca1b2a	addColumn tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
79110	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.79.0.xml	2021-03-04 04:34:32.568993	137	EXECUTED	7:9311a902d664e6cac8e9d80fa5ead7bb	sql; createIndex indexName=IDX_API_KEYS_NAME_USER, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
79120	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.79.0.xml	2021-03-04 04:34:32.574413	138	EXECUTED	7:bd68d00d087f01a6a159089ffa2368f1	addColumn tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
79130	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.79.0.xml	2021-03-04 04:34:32.584076	139	EXECUTED	7:a3967bc088d6162337d362f3ee40b0f3	addColumn tableName=USERS		\N	3.5.1	\N	\N	4832469142
79200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.79.0.xml	2021-03-04 04:34:32.595793	140	EXECUTED	7:0f5ed55d668072c49876af504daead7c	addColumn tableName=PROCESS_QUEUE; addForeignKeyConstraint baseTableName=PROCESS_QUEUE, constraintName=FK_PQ_REPO_ID, referencedTableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
80000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.80.0.xml	2021-03-04 04:34:32.60389	141	EXECUTED	7:384f9be2f873a3b6209c15b3ac08057c	insert tableName=ROLES; insert tableName=USER_ROLES		\N	3.5.1	\N	\N	4832469142
81000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.81.0.xml	2021-03-04 04:34:32.619636	142	EXECUTED	7:bb5c13b7c31b9d826b35bfe229273e75	addColumn tableName=PROCESS_STATE		\N	3.5.1	\N	\N	4832469142
81100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.81.0.xml	2021-03-04 04:34:32.635266	143	EXECUTED	7:6c71908ec9d554fac9de8fc714aba984	createTable tableName=TASK_LOCKS; insert tableName=TASK_LOCKS; insert tableName=TASK_LOCKS		\N	3.5.1	\N	\N	4832469142
83000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.83.0.xml	2021-03-04 04:34:32.644273	144	EXECUTED	7:cdb470a19050686b749ff6cba1093f92	addColumn tableName=TRIGGERS		\N	3.5.1	\N	\N	4832469142
84000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.84.0.xml	2021-03-04 04:34:32.669455	145	EXECUTED	7:a8f71a204534c7b933683b7c35e434b9	createTable tableName=PROCESS_CHECKPOINTS; addForeignKeyConstraint baseTableName=PROCESS_CHECKPOINTS, constraintName=FK_PCHECKP_PQ_ID, referencedTableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
85000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.85.0.xml	2021-03-04 04:34:32.681958	146	EXECUTED	7:42c5af1acf5bace053979ac10efffeb2	createIndex indexName=IDX_PROC_Q_CURR_STAT, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
86000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.86.0.xml	2021-03-04 04:34:32.689554	147	EXECUTED	7:0bd22f258406490fd222f5b634c16ce5	addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
86200	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v0.86.0.xml	2021-03-04 04:34:32.726831	148	EXECUTED	7:7f98aca84a26a8c360eeadac96c617a9	addColumn tableName=PROCESS_QUEUE; addForeignKeyConstraint baseTableName=PROCESS_QUEUE, constraintName=FK_PQ_INITIATOR_ID, referencedTableName=USERS; createProcedure; createProcedure; sql; sql		\N	3.5.1	\N	\N	4832469142
86300	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v0.86.0.xml	2021-03-04 04:34:32.736075	149	EXECUTED	7:074b217498d6560d66da0f579e741301	addColumn tableName=PROCESS_CHECKPOINTS		\N	3.5.1	\N	\N	4832469142
87000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.87.0.xml	2021-03-04 04:34:32.741722	150	EXECUTED	7:951b29ec49b36916a02515f8bb365ab9	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
87100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.87.0.xml	2021-03-04 04:34:32.750605	151	EXECUTED	7:016c026597270d3f381cd650e01e4638	addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
87300	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v0.87.0.xml	2021-03-04 04:34:32.764762	152	EXECUTED	7:efa592bce7f694c3c8e68a63ac5cdcb6	sql; dropColumn columnName=INITIATOR, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
88000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.88.0.xml	2021-03-04 04:34:32.778019	153	EXECUTED	7:a525a47d38eeeae6d34e5dd054f61482	sql		\N	3.5.1	\N	\N	4832469142
88010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.88.0.xml	2021-03-04 04:34:32.785245	154	EXECUTED	7:08e25d514bd454df13d99cd371aaa80b	sql		\N	3.5.1	\N	\N	4832469142
89000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.89.0.xml	2021-03-04 04:34:32.792478	155	EXECUTED	7:90c360f762dfb736a541437c6e22ce18	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
89200	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.89.0.xml	2021-03-04 04:34:32.800052	156	EXECUTED	7:1101c0ad37ac36fe4719ba74e31db42f	addColumn tableName=ORGANIZATIONS		\N	3.5.1	\N	\N	4832469142
89500	muhammad.amir@walmart.com	com/walmartlabs/concord/server/db/v0.89.0.xml	2021-03-04 04:34:32.81359	157	EXECUTED	7:f322cd026dc70261f4da27fe9d5f2a64	addColumn tableName=TRIGGERS; dropNotNullConstraint columnName=ENTRY_POINT, tableName=TRIGGERS; sql; dropColumn columnName=ENTRY_POINT, tableName=TRIGGERS		\N	3.5.1	\N	\N	4832469142
90000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.90.0.xml	2021-03-04 04:34:32.823108	158	EXECUTED	7:f7f2ebdb3e0afa95579238aac8201fda	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
92000	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v0.92.0.xml	2021-03-04 04:34:32.834443	159	EXECUTED	7:9826c876669b569c42307f5be476013f	addColumn tableName=POLICY_LINKS; addForeignKeyConstraint baseTableName=POLICY_LINKS, constraintName=FK_POLICY_LINKS_USER_ID, referencedTableName=USERS		\N	3.5.1	\N	\N	4832469142
92010	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v0.92.0.xml	2021-03-04 04:34:32.850928	160	EXECUTED	7:67606046fc6f44110131641ad2012a36	createIndex indexName=IDX_POLICY_LINK_5, tableName=POLICY_LINKS		\N	3.5.1	\N	\N	4832469142
92030	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v0.92.0.xml	2021-03-04 04:34:32.860956	161	EXECUTED	7:362221cb15a33acdf389c97ff4a02654	createIndex indexName=IDX_POLICY_LINK_6, tableName=POLICY_LINKS		\N	3.5.1	\N	\N	4832469142
93000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.93.0.xml	2021-03-04 04:34:32.872844	162	EXECUTED	7:3a79bb679322f7d16488c09d1a691b58	createTable tableName=TASKS		\N	3.5.1	\N	\N	4832469142
93100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.93.0.xml	2021-03-04 04:34:32.885518	163	EXECUTED	7:7445d7ef4d7d5fa7b2d59887c54aefa1	addColumn tableName=TASKS		\N	3.5.1	\N	\N	4832469142
93500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.93.0.xml	2021-03-04 04:34:32.907238	164	EXECUTED	7:751201d38227b3b86e68f1e35a71417a	addColumn tableName=PROCESS_STATE; sql; addNotNullConstraint columnName=INSTANCE_CREATED_AT, tableName=PROCESS_STATE; dropPrimaryKey tableName=PROCESS_STATE; addPrimaryKey tableName=PROCESS_STATE		\N	3.5.1	\N	\N	4832469142
97000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.97.0.xml	2021-03-04 04:34:32.916524	165	EXECUTED	7:bec1e005488b9aacf39edddff56a096d	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
97100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.97.0.xml	2021-03-04 04:34:32.929869	166	EXECUTED	7:b845e5e69ccd0903aed96270874a54cc	dropIndex indexName=IDX_PROC_EV_I_ID_DT, tableName=PROCESS_EVENTS; createIndex indexName=IDX_PROC_EV_I_ID_DT_TYPE, tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
99000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.99.0.xml	2021-03-04 04:34:32.942135	167	EXECUTED	7:86f200ee337746f016392a20c455dfad	sql; addNotNullConstraint columnName=INSTANCE_CREATED_AT, tableName=PROCESS_EVENTS; dropIndex indexName=IDX_PROC_EV_I_ID_DT_TYPE, tableName=PROCESS_EVENTS; createIndex indexName=IDX_PROC_EVENTS, tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
99300	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v0.99.0.xml	2021-03-04 04:34:32.95184	168	EXECUTED	7:735eb75676d8652655799956921d9dcd	createIndex indexName=IDX_PROC_EVENTS_FOLDING, tableName=PROCESS_EVENTS		\N	3.5.1	\N	\N	4832469142
99400	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v0.99.0.xml	2021-03-04 04:34:32.960346	169	EXECUTED	7:d36376f96e880de69f174555281bd791	addColumn tableName=POLICIES; addForeignKeyConstraint baseTableName=POLICIES, constraintName=FK_POLICIES_PARENT, referencedTableName=POLICIES		\N	3.5.1	\N	\N	4832469142
150000	muhammad.amir@walmart.com	com/walmartlabs/concord/server/db/v1.5.0.xml	2021-03-04 04:34:32.968981	170	EXECUTED	7:23e24577875ab197c657a5a7798b493d	addColumn tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
170000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.7.0.xml	2021-03-04 04:34:32.97748	171	EXECUTED	7:17ac04f16a1da454e382dd2531100848	insert tableName=ROLES; sql		\N	3.5.1	\N	\N	4832469142
170100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.7.0.xml	2021-03-04 04:34:32.983561	172	EXECUTED	7:58f117eaa000ec0721a51149c99c339d	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
180000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.8.0.xml	2021-03-04 04:34:33.000931	173	EXECUTED	7:bf7362f64e1f183d28c1dddb05abfd80	sql; createTable tableName=PROCESS_LOCKS; addForeignKeyConstraint baseTableName=PROCESS_LOCKS, constraintName=FK_PROCESS_LOCKS_INSTANCE_ID, referencedTableName=PROCESS_QUEUE; addForeignKeyConstraint baseTableName=PROCESS_LOCKS, constraintName=FK_P...		\N	3.5.1	\N	\N	4832469142
180010	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.8.0.xml	2021-03-04 04:34:33.012274	174	EXECUTED	7:dc52dbc394b4758ef0e66ab6ff3ab129	createIndex indexName=IDX_PROCESS_LOCKS_1, tableName=PROCESS_LOCKS		\N	3.5.1	\N	\N	4832469142
180020	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.8.0.xml	2021-03-04 04:34:33.020819	175	EXECUTED	7:a93ac51db4770afb14fbcf7c80cf5853	createIndex indexName=IDX_PROCESS_LOCKS_2, tableName=PROCESS_LOCKS		\N	3.5.1	\N	\N	4832469142
1100000	muhammad.amir@walmart.com	com/walmartlabs/concord/server/db/v1.10.0.xml	2021-03-04 04:34:33.037977	176	EXECUTED	7:8f0817f85b1f6e0adf8b9e4047be5d88	addColumn tableName=REPOSITORIES		\N	3.5.1	\N	\N	4832469142
1120000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.12.0.xml	2021-03-04 04:34:33.058137	177	EXECUTED	7:a934bc9ca2ebb4e7b2eef0de5fabbe33	addColumn tableName=USERS		\N	3.5.1	\N	\N	4832469142
1120010	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.12.0.xml	2021-03-04 04:34:33.103609	178	EXECUTED	7:a64c105f7068eb35512c9bd0f37af66b	createTable tableName=USER_LDAP_GROUPS; addForeignKeyConstraint baseTableName=USER_LDAP_GROUPS, constraintName=FK_USER_LDAP_GROUPS_USER_ID, referencedTableName=USERS		\N	3.5.1	\N	\N	4832469142
1120020	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.12.0.xml	2021-03-04 04:34:33.128189	179	EXECUTED	7:dc88dba97dc7798f2e8fea437d4473d9	createTable tableName=TEAM_LDAP_GROUPS; addUniqueConstraint tableName=TEAM_LDAP_GROUPS		\N	3.5.1	\N	\N	4832469142
1120030	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.12.0.xml	2021-03-04 04:34:33.150354	180	EXECUTED	7:a03593d961b502fae31f915563ca4efc	createView viewName=V_USER_TEAMS		\N	3.5.1	\N	\N	4832469142
1130000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.13.0.xml	2021-03-04 04:34:33.174995	181	EXECUTED	7:89f394a3d2703c559c6839087ce4a802	dropForeignKeyConstraint baseTableName=PROJECTS, constraintName=FK_PRJ_ORG_ID; addForeignKeyConstraint baseTableName=PROJECTS, constraintName=FK_PRJ_ORG_ID, referencedTableName=ORGANIZATIONS; dropForeignKeyConstraint baseTableName=INVENTORIES, con...		\N	3.5.1	\N	\N	4832469142
1130100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.13.0.xml	2021-03-04 04:34:33.1927	182	EXECUTED	7:65a78f35c58aa659d0734d24a261bc19	addColumn tableName=ORGANIZATIONS; addForeignKeyConstraint baseTableName=ORGANIZATIONS, constraintName=FK_ORG_OWNER_ID, referencedTableName=USERS		\N	3.5.1	\N	\N	4832469142
1130200	muhammad.amir@walmart.com	com/walmartlabs/concord/server/db/v1.13.0.xml	2021-03-04 04:34:33.220665	183	EXECUTED	7:c382e5e6530753a741e062fa9ef126e8	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1180000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.18.0.xml	2021-03-04 04:34:33.241044	184	EXECUTED	7:33e7f80cbfc017806982708c0ee21308	createTable tableName=PERMISSIONS; insert tableName=PERMISSIONS; createTable tableName=ROLE_PERMISSIONS; addForeignKeyConstraint baseTableName=ROLE_PERMISSIONS, constraintName=FK_ROLE_PERMISSIONS, referencedTableName=PERMISSIONS		\N	3.5.1	\N	\N	4832469142
1180100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.18.0.xml	2021-03-04 04:34:33.250479	185	EXECUTED	7:02e34c8f57e85e86ef713643f9ae0026	addColumn tableName=PROCESS_CHECKPOINTS; sql; addNotNullConstraint columnName=INSTANCE_CREATED_AT, tableName=PROCESS_CHECKPOINTS		\N	3.5.1	\N	\N	4832469142
1210000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.21.0.xml	2021-03-04 04:34:33.25672	186	EXECUTED	7:009d8f9389585c45909dac30b43781aa	addColumn tableName=USERS		\N	3.5.1	\N	\N	4832469142
1220000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.22.0.xml	2021-03-04 04:34:33.261682	187	EXECUTED	7:3c0bc4d3cbd5e04b059558763ee8e5f0	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1240000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.24.0.xml	2021-03-04 04:34:33.267171	188	EXECUTED	7:c7956ae9cda65d3c3f69e78275b2e1d4	dropForeignKeyConstraint baseTableName=PROCESS_CHECKPOINTS, constraintName=FK_PCHECKP_PQ_ID		\N	3.5.1	\N	\N	4832469142
1240100	muhammad.wasi@walmart.com	com/walmartlabs/concord/server/db/v1.24.0.xml	2021-03-04 04:34:33.277777	189	EXECUTED	7:a2e2af99dcc920c06dee501276f9be8a	addForeignKeyConstraint baseTableName=ROLE_PERMISSIONS, constraintName=FK_ROLE_PERMISSIONS_ROLES, referencedTableName=ROLES; dropForeignKeyConstraint baseTableName=USER_ROLES, constraintName=FK_U_R_ROLE; addForeignKeyConstraint baseTableName=USER_...		\N	3.5.1	\N	\N	4832469142
1240100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.24.0.xml	2021-03-04 04:34:33.284372	190	EXECUTED	7:27774f385855aff932f6eb9a879521e4	addColumn tableName=USERS		\N	3.5.1	\N	\N	4832469142
1240110	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.24.0.xml	2021-03-04 04:34:33.295372	191	EXECUTED	7:b12731995f598a3aefa782965b3fa535	dropUniqueConstraint constraintName=USERS_USERNAME_KEY, tableName=USERS; addUniqueConstraint tableName=USERS		\N	3.5.1	\N	\N	4832469142
1270100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.27.0.xml	2021-03-04 04:34:33.301095	192	EXECUTED	7:d08bb5d2630d59cccb566c1ad1c00096	dropIndex indexName=IDX_PROC_Q_CURR_STAT, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1280000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.28.0.xml	2021-03-04 04:34:33.306271	193	EXECUTED	7:999edb85f3863ce87ccba786189ac75d	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1280200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.28.0.xml	2021-03-04 04:34:33.324848	194	EXECUTED	7:bd2d68a15cb21612244e653036b97275	sql; addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
1280210	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.28.0.xml	2021-03-04 04:34:33.332016	195	MARK_RAN	7:300d7252c2c983753948df72d3948731	sql		\N	3.5.1	\N	\N	4832469142
1330000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.33.0.xml	2021-03-04 04:34:33.340331	196	EXECUTED	7:b81dd0aa9ac332254c70ac9bf9d3ada2	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1340000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.34.0.xml	2021-03-04 04:34:33.34804	197	MARK_RAN	7:c4f908aabae131fcc9bcb034b1289a06	sql		\N	3.5.1	\N	\N	4832469142
1340100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.0.xml	2021-03-04 04:34:33.355489	198	EXECUTED	7:97f26cacac68dce93697ed34172f7797	dropIndex indexName=IDX_API_KEY, tableName=API_KEYS		\N	3.5.1	\N	\N	4832469142
1340110	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.0.xml	2021-03-04 04:34:33.365575	199	EXECUTED	7:7a783d3f0be4ed5c695d73cd27c2ae5f	sql		\N	3.5.1	\N	\N	4832469142
1340120	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.0.xml	2021-03-04 04:34:33.373173	200	EXECUTED	7:9d8fbf5325c3bde7d98278fa251000ce	dropIndex indexName=IDX_PROC_Q_POLL, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1340130	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.0.xml	2021-03-04 04:34:33.382882	201	EXECUTED	7:a8bbbcb8fbaebac94a913f69d33ca65a	sql		\N	3.5.1	\N	\N	4832469142
1341000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.34.1.xml	2021-03-04 04:34:33.389585	202	EXECUTED	7:df5ca440a42a8945e911796e90b2e7ea	sql		\N	3.5.1	\N	\N	4832469142
1341100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.34.1.xml	2021-03-04 04:34:33.39603	203	MARK_RAN	7:312fb35c88ba8d86bad9797703634cb7	dropColumn columnName=TRIGGER_VERSION, tableName=TRIGGERS		\N	3.5.1	\N	\N	4832469142
1342000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.2.xml	2021-03-04 04:34:33.413128	204	MARK_RAN	7:c3e07d09e6fcdc0fe0928d54597534ad	dropIndex indexName=IDX_A_CMD_A_ID, tableName=AGENT_COMMANDS		\N	3.5.1	\N	\N	4832469142
1342010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.2.xml	2021-03-04 04:34:33.421712	205	EXECUTED	7:15542083eec88c718795036a23e7b838	createIndex indexName=IDX_A_CMD_STATUS, tableName=AGENT_COMMANDS		\N	3.5.1	\N	\N	4832469142
1344000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.441698	206	EXECUTED	7:93ac71fad3e62bd42963322eaca1565c	sql		\N	3.5.1	\N	\N	4832469142
1344010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.451729	207	EXECUTED	7:0cd683c1965021928ec7e67dfb69ff82	sql		\N	3.5.1	\N	\N	4832469142
1344020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.45915	208	EXECUTED	7:cd4e4dfb977e9cdcbdc78e4513d3f048	sql		\N	3.5.1	\N	\N	4832469142
1344030	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.465205	209	EXECUTED	7:6447ace9f5c81b181c4dd2def308881c	sql		\N	3.5.1	\N	\N	4832469142
1344100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.501202	210	MARK_RAN	7:7081d4e1d40b8da8044c35de9c4ac193	dropTable tableName=EVENT_PROCESSOR_MARKER		\N	3.5.1	\N	\N	4832469142
1344110	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.512112	211	EXECUTED	7:cc6ee6aaca83c56723be387e198ea856	createTable tableName=EVENT_PROCESSOR_MARKER		\N	3.5.1	\N	\N	4832469142
1344120	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.545539	212	MARK_RAN	7:3cd10fb1783e1b5cd143250e55e77640	sql		\N	3.5.1	\N	\N	4832469142
1344200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.553733	213	EXECUTED	7:b13b257ad1947817f7eed0393195f04f	sql		\N	3.5.1	\N	\N	4832469142
1344300	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.34.3.xml	2021-03-04 04:34:33.568618	214	EXECUTED	7:ffd90800319c1627c71705188db22d41	sql		\N	3.5.1	\N	\N	4832469142
1350000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.35.0.xml	2021-03-04 04:34:33.59822	215	EXECUTED	7:7b86e683b7a4efae1b61e02b92f6ece3	sql		\N	3.5.1	\N	\N	4832469142
1380000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.38.0.xml	2021-03-04 04:34:33.606085	216	EXECUTED	7:a96f5bd2fc3d2aae0620e7954f2a3e3c	sql		\N	3.5.1	\N	\N	4832469142
1380100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.38.0.xml	2021-03-04 04:34:33.616914	217	EXECUTED	7:706d50b3b8b2fb9d2c7c24148b88a265	addColumn tableName=INVENTORY_DATA		\N	3.5.1	\N	\N	4832469142
1380110	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.38.0.xml	2021-03-04 04:34:33.629108	218	EXECUTED	7:d18ea3ccf35892e8c2d14e03066ee61b	renameTable newTableName=JSON_STORES, oldTableName=INVENTORIES; renameTable newTableName=JSON_STORE_DATA, oldTableName=INVENTORY_DATA; renameTable newTableName=JSON_STORE_QUERIES, oldTableName=INVENTORY_QUERIES; renameTable newTableName=JSON_STORE...		\N	3.5.1	\N	\N	4832469142
1380120	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.38.0.xml	2021-03-04 04:34:33.644605	219	EXECUTED	7:da8328cd8098e73a55f2a58231d9a90b	renameColumn newColumnName=JSON_STORE_ID, oldColumnName=INVENTORY_ID, tableName=JSON_STORES; renameColumn newColumnName=JSON_STORE_NAME, oldColumnName=INVENTORY_NAME, tableName=JSON_STORES; renameColumn newColumnName=JSON_STORE_ID, oldColumnName=I...		\N	3.5.1	\N	\N	4832469142
1380130	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.38.0.xml	2021-03-04 04:34:33.664518	220	EXECUTED	7:1048b0d2cdd764a3c203fd61760402d1	createView viewName=INVENTORIES; createView viewName=INVENTORY_DATA; createView viewName=INVENTORY_QUERIES		\N	3.5.1	\N	\N	4832469142
1400000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.40.0.xml	2021-03-04 04:34:33.681606	221	MARK_RAN	7:4f71b5dab91a94ad0eb62a82c8218fe3	dropIndex indexName=IDX_PROC_WAIT_COND_NN, tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1400010	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.40.0.xml	2021-03-04 04:34:33.689867	222	EXECUTED	7:ff54bd85935f957f10f3f83d31421e4d	sql		\N	3.5.1	\N	\N	4832469142
1410000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.41.0.xml	2021-03-04 04:34:33.697135	223	EXECUTED	7:412e76c0f2252f3e956aef9a72323167	sql		\N	3.5.1	\N	\N	4832469142
1430000	pranav.r.parikh@gmail.com	com/walmartlabs/concord/server/db/v1.43.0.xml	2021-03-04 04:34:33.702074	224	EXECUTED	7:876266501e97ab1befc116efc842ca56	sql		\N	3.5.1	\N	\N	4832469142
1450000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.45.0.xml	2021-03-04 04:34:33.715553	225	EXECUTED	7:92a0331c0e8d16bc8c880a2c7dd505f2	sql; customChange		\N	3.5.1	!codegen	\N	4832469142
1480000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.48.0.xml	2021-03-04 04:34:33.720687	226	EXECUTED	7:3649ed5494485df777a36235e377b907	sql		\N	3.5.1	\N	\N	4832469142
1490000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.726549	227	EXECUTED	7:c6e035c9df3f35bb37994b8f40e8e3f5	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1490010	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.737511	228	EXECUTED	7:b70de8118884fd89025bb9ed8a8b0572	createTable tableName=PROCESS_LOG_SEGMENTS		\N	3.5.1	\N	\N	4832469142
1490011	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.745971	229	EXECUTED	7:c593afa3fc6179b2e48c6ba9402b2bdd	createIndex indexName=IDX_PLS_IDS, tableName=PROCESS_LOG_SEGMENTS		\N	3.5.1	\N	\N	4832469142
1490020	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.75907	230	EXECUTED	7:10ab12d5b908de504f897e6e2a773036	createTable tableName=PROCESS_LOG_DATA		\N	3.5.1	\N	\N	4832469142
1490030	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.766479	231	EXECUTED	7:8d97fbc9a17c34572b06cb72573075c0	createIndex indexName=IDX_PLD_IDS, tableName=PROCESS_LOG_DATA		\N	3.5.1	\N	\N	4832469142
1490040	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.783095	232	EXECUTED	7:bcbd720081a346a7f3ff5c996560da1c	createProcedure; createProcedure		\N	3.5.1	\N	\N	4832469142
1490050	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.793052	233	EXECUTED	7:74feca89d68ef369526282daeccb97ea	createProcedure		\N	3.5.1	\N	\N	4832469142
1490060	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.49.0.xml	2021-03-04 04:34:33.799183	234	EXECUTED	7:e9e8b7686e8b15dcc0a1cf650d905624	createProcedure		\N	3.5.1	\N	\N	4832469142
1560000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.56.0.xml	2021-03-04 04:34:33.80476	235	EXECUTED	7:638db90264634b35f196b625da80c4ac	sql		\N	3.5.1	\N	\N	4832469142
1560010	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.56.0.xml	2021-03-04 04:34:33.810031	236	EXECUTED	7:a07f219f73e02cbeed963f77485920d6	sql		\N	3.5.1	\N	\N	4832469142
1560020	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.56.0.xml	2021-03-04 04:34:33.820698	237	EXECUTED	7:cb7868f036bc6dbdd8b91b9f00cd58f2	dropUniqueConstraint constraintName=USERS_USERNAME_DOMAIN_USER_TYPE_KEY, tableName=USERS		\N	3.5.1	\N	\N	4832469142
1560030	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.56.0.xml	2021-03-04 04:34:33.830186	238	EXECUTED	7:5ff799644b32d0d5efa9650dd34759f3	createIndex indexName=IDX_USERS_UNIQ, tableName=USERS		\N	3.5.1	\N	\N	4832469142
1560040	benjamin.broadaway@walmart.com	com/walmartlabs/concord/server/db/v1.56.0.xml	2021-03-04 04:34:33.837636	239	EXECUTED	7:ead9933366b8be3a8902595b72069937	sql		\N	3.5.1	\N	\N	4832469142
1560050	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.56.0.xml	2021-03-04 04:34:33.889772	240	EXECUTED	7:814490917fd400b881b94490dc4912e1	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1570000	benjamin.broadaway@walmart.com	com/walmartlabs/concord/server/db/v1.57.0.xml	2021-03-04 04:34:33.921998	241	EXECUTED	7:39ac38cac8d42f5b2b34b8db127e74ce	insert tableName=PERMISSIONS; sql		\N	3.5.1	\N	\N	4832469142
1580000	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:33.950927	242	EXECUTED	7:67441abef35bde9717178d1f61394a2c	createProcedure		\N	3.5.1	\N	\N	4832469142
1580100	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:33.975481	243	EXECUTED	7:0b52512eadc40b27a61e4a6112f2abc8	sql		\N	3.5.1	\N	\N	4832469142
1580100-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:33.982066	244	MARK_RAN	7:3a9e0031fc3e7f3a1647e76606f29d74	sql		\N	3.5.1	\N	\N	4832469142
1580110	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:33.993568	245	EXECUTED	7:5f3ad797d082d13acccbb58f123926fe	sql		\N	3.5.1	\N	\N	4832469142
1580110-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:33.997798	246	MARK_RAN	7:20295d606f0101cb0b217bac660a4132	sql		\N	3.5.1	\N	\N	4832469142
1580120	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.013626	247	EXECUTED	7:4d0fc19f03d91402dc193d32f7e1be32	sql		\N	3.5.1	\N	\N	4832469142
1580120-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.020976	248	MARK_RAN	7:ea33acdfa513f1a6898938c32b46b667	sql		\N	3.5.1	\N	\N	4832469142
1580130	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.039291	249	EXECUTED	7:ac0e0471e6ba6fb1f333bd1aed410e0b	sql		\N	3.5.1	\N	\N	4832469142
1580130-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.044313	250	MARK_RAN	7:daaa1ed1ab154a3526b4ecbe5fecb371	sql		\N	3.5.1	\N	\N	4832469142
1580140	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.059096	251	EXECUTED	7:6c3bf6f087fe92cf18b1427009c7f21c	sql		\N	3.5.1	\N	\N	4832469142
1580140-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.070029	252	MARK_RAN	7:e907dda775ea71a5254eb168e2f4b2b2	sql		\N	3.5.1	\N	\N	4832469142
1580150	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.099412	253	EXECUTED	7:4e52b2869f6b1ad332eec9b4c794f968	sql		\N	3.5.1	\N	\N	4832469142
1580150-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.107682	254	MARK_RAN	7:3f335d5da84be5f98d306f0309cf4676	sql		\N	3.5.1	\N	\N	4832469142
1580160	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.120634	255	EXECUTED	7:7cb4a7348f7638229360e61800e0e20a	sql		\N	3.5.1	\N	\N	4832469142
1580160-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.128115	256	MARK_RAN	7:c9da4ed7323beb23de72eccd2d0bb060	sql		\N	3.5.1	\N	\N	4832469142
1580200	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.153816	257	EXECUTED	7:abab9bd604a0e595efd91c45de868123	sql		\N	3.5.1	\N	\N	4832469142
1580200-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.167624	258	MARK_RAN	7:0415f1854d1f087f0e52563eddf066ef	dropView viewName=V_AUDIT_LOG; sql		\N	3.5.1	\N	\N	4832469142
1580201	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.194425	259	EXECUTED	7:510af4d229242501e25707b1ad503417	createView viewName=V_AUDIT_LOG		\N	3.5.1	\N	\N	4832469142
1580210	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.208118	260	EXECUTED	7:3f69d9f513fc222afb28275c83e1379d	sql		\N	3.5.1	\N	\N	4832469142
1580210-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.217241	261	MARK_RAN	7:92eccc7b6ea314a8383621750fa29e93	sql		\N	3.5.1	\N	\N	4832469142
1580220	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.268774	262	EXECUTED	7:1e7bb15f38fd6b7f03b4606a7f73b6d1	sql		\N	3.5.1	\N	\N	4832469142
1580220-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.275447	263	MARK_RAN	7:15ac4448f1e38debad7b9f652c60852d	sql		\N	3.5.1	\N	\N	4832469142
1580230	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.303072	264	EXECUTED	7:80c903f8a1154fbeb7186906ae9291f0	sql		\N	3.5.1	\N	\N	4832469142
1580230-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.309661	265	MARK_RAN	7:45b0e5126bce2c13684b4198071b7dd8	sql		\N	3.5.1	\N	\N	4832469142
1580240	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.342128	266	EXECUTED	7:1c0757e5e07340f620b3f874a377b644	sql		\N	3.5.1	\N	\N	4832469142
1580240-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.34579	267	MARK_RAN	7:1be8b70918b30029066ffcc72d785add	sql		\N	3.5.1	\N	\N	4832469142
1580250	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.363632	268	EXECUTED	7:a310651abeb95de8d9c67e624094d336	sql		\N	3.5.1	\N	\N	4832469142
1580250-a	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.370847	269	MARK_RAN	7:cccbac9948271d36e8799c291694d7d0	sql		\N	3.5.1	\N	\N	4832469142
1580300	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.389197	270	EXECUTED	7:c5b69d8604b167a3ec428c54f00bb200	sql		\N	3.5.1	\N	\N	4832469142
1580500	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.406116	271	EXECUTED	7:24735a99122eaa89ad470f4b022e8ca3	createProcedure; createProcedure		\N	3.5.1	\N	\N	4832469142
1580510	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.420172	272	EXECUTED	7:e8831583baffc8a680e1d4735061d672	createProcedure		\N	3.5.1	\N	\N	4832469142
1580520	ibodrov@gmail.com	com/walmartlabs/concord/server/db/v1.58.0.xml	2021-03-04 04:34:34.441071	273	EXECUTED	7:fb760e0f6d0f07bce2606a1ba9ba9137	createProcedure		\N	3.5.1	\N	\N	4832469142
1600000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.60.0.xml	2021-03-04 04:34:34.451733	274	EXECUTED	7:d0271204195a7a3079f484d8dcd0c968	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1650000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.66.0.xml	2021-03-04 04:34:34.486624	275	EXECUTED	7:ec02620bc327c62fa1efdf5d7e57cc8a	sql; addColumn tableName=PROJECTS		\N	3.5.1	\N	\N	4832469142
1690000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.69.0.xml	2021-03-04 04:34:34.518208	276	EXECUTED	7:83ac4ce14b2e0850b14765127769baaa	addColumn tableName=TASKS; addColumn tableName=TASKS; sql; sql		\N	3.5.1	\N	\N	4832469142
1750000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.75.0.xml	2021-03-04 04:34:34.536506	277	EXECUTED	7:426f991324ff62afe34b996891967aa3	sql		\N	3.5.1	\N	\N	4832469142
1760000	amith.k.b@walmartlabs.com	com/walmartlabs/concord/server/db/v1.76.0.xml	2021-03-04 04:34:34.54632	278	EXECUTED	7:8e2525517c393f2a22dd8850d46e2fb4	sql		\N	3.5.1	\N	\N	4832469142
1760100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.76.0.xml	2021-03-04 04:34:34.55256	279	EXECUTED	7:8d3b4d15f25ec0f4f7eb65bea4a39dee	sql		\N	3.5.1	\N	\N	4832469142
1780000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.78.0.xml	2021-03-04 04:34:34.560749	280	EXECUTED	7:3f7ffa931d49d329a2726e894afab284	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
1780100	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.78.0.xml	2021-03-04 04:34:34.576038	281	EXECUTED	7:5ef72e9497bf7b4c69ce2cadd739195c	createView viewName=json_store_data_view_restricted; createView viewName=INVENTORY_DATA		\N	3.5.1	\N	\N	4832469142
1790000	ybrigo@gmail.com	com/walmartlabs/concord/server/db/v1.79.0.xml	2021-03-04 04:34:34.584029	282	EXECUTED	7:3b1de516ffba57a16f7f52942ae4ade1	addColumn tableName=PROCESS_QUEUE		\N	3.5.1	\N	\N	4832469142
ansible-10000	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.774131	283	EXECUTED	7:873fd00d91d131f74cbf1804ca041670	createTable tableName=ANSIBLE_HOSTS		\N	3.5.1	\N	\N	4832474739
ansible-10001	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.792465	284	EXECUTED	7:484c007df40618edf708537e5903bed3	createTable tableName=ANSIBLE_PLAYBOOK_STATS		\N	3.5.1	\N	\N	4832474739
ansible-10002	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.804042	285	EXECUTED	7:e623e3934f9e3cb8ec1a7c11046a579e	createTable tableName=ANSIBLE_PLAYBOOK_RESULT		\N	3.5.1	\N	\N	4832474739
ansible-10003	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.820908	286	EXECUTED	7:acd0e94462263f8bdf25030ccd53e002	createTable tableName=ANSIBLE_PLAY_STATS		\N	3.5.1	\N	\N	4832474739
ansible-10004	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.839856	287	EXECUTED	7:96f91c8c5e88e9eb931b245f189f9e02	createTable tableName=ANSIBLE_TASK_STATS		\N	3.5.1	\N	\N	4832474739
ansible-10005	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.848955	288	EXECUTED	7:d84acb3b647475bae85734b92d3fbd06	addColumn tableName=ANSIBLE_HOSTS		\N	3.5.1	\N	\N	4832474739
ansible-10006	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.867899	289	EXECUTED	7:71cd4b80eec1d21758c42716509e52cb	createIndex indexName=IDX_A_PLAYBOOK_STATS, tableName=ANSIBLE_PLAYBOOK_STATS; createIndex indexName=IDX_A_PLAYBOOK_RESULT, tableName=ANSIBLE_PLAYBOOK_RESULT; createIndex indexName=IDX_A_PLAY_STATS, tableName=ANSIBLE_PLAY_STATS; createIndex indexNa...		\N	3.5.1	\N	\N	4832474739
ansible-10007	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.884963	290	EXECUTED	7:580948866c7ca1112e8ca484e4703989	dropPrimaryKey tableName=ANSIBLE_HOSTS; addPrimaryKey tableName=ANSIBLE_HOSTS		\N	3.5.1	\N	\N	4832474739
ansible-10008	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.892202	291	EXECUTED	7:daf2d2cfd18dd005b8700b117c10942b	addColumn tableName=ANSIBLE_PLAYBOOK_STATS		\N	3.5.1	\N	\N	4832474739
ansible-1580000	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.900857	292	EXECUTED	7:67441abef35bde9717178d1f61394a2c	createProcedure		\N	3.5.1	\N	\N	4832474739
ansible-1580100	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.911073	293	EXECUTED	7:9a803d308662af5a3a1fcbcc951b951a	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580100-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.916204	294	MARK_RAN	7:62024c1f823aff8378849d738d521d25	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580110	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.929137	295	EXECUTED	7:8016ae7c901ef559b5a69c4ea93f5d35	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580110-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.933514	296	MARK_RAN	7:f1e7ba3d93724ae1a00343f2c60653e5	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580120	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.942016	297	EXECUTED	7:0fdea91bc3f96daf1a517a70861244c5	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580120-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.945222	298	MARK_RAN	7:dec82d48f3508151c253849cd5bd6e1e	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580130	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.956655	299	EXECUTED	7:8dbd7894c6a56adb1069edde822132a2	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580130-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.960358	300	MARK_RAN	7:1034e4dd64fe54b6e54f5a2034033b25	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580140	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.968221	301	EXECUTED	7:90c2744141497e86ea9500f59718f653	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580140-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.972369	302	MARK_RAN	7:abbf6ae4ded524e2c4633b28aaf5e901	sql		\N	3.5.1	\N	\N	4832474739
ansible-1580200	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/ansible/db/liquibase.xml	2021-03-04 04:34:34.988651	303	EXECUTED	7:33a4104c3b940bce2959af5afaf5fa8f	sql; sql; sql; sql		\N	3.5.1	\N	\N	4832474739
noderoster-10000	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.333829	304	EXECUTED	7:19b9f75dbeb4f4969f1d59c7643fc723	sql		\N	3.5.1	\N	\N	4832483312
noderoster-10020	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.354294	305	EXECUTED	7:cc2317a5e4404253c8ddf1ffa285181f	createTable tableName=NODE_ROSTER_HOSTS		\N	3.5.1	\N	\N	4832483312
noderoster-10030	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.366055	306	EXECUTED	7:2a94330e4f19d2f1a8144413ac749a4e	createTable tableName=NODE_ROSTER_PROCESS_HOSTS		\N	3.5.1	\N	\N	4832483312
noderoster-10040	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.388463	307	EXECUTED	7:1b3a4cdfe438e231f0e3ae99574d9e44	createTable tableName=NODE_ROSTER_HOST_FACTS		\N	3.5.1	\N	\N	4832483312
noderoster-10050	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.406004	308	EXECUTED	7:6d8431e1969cd094e91abb642856ec09	createTable tableName=NODE_ROSTER_HOST_ARTIFACTS		\N	3.5.1	\N	\N	4832483312
noderoster-10060	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.436526	309	EXECUTED	7:0fd3ef26c76829bc0a5ec8019bf7993b	addColumn tableName=NODE_ROSTER_HOST_FACTS; dropPrimaryKey tableName=NODE_ROSTER_HOST_FACTS; createIndex indexName=IDX_NR_HF_HOST, tableName=NODE_ROSTER_HOST_FACTS		\N	3.5.1	\N	\N	4832483312
noderoster-10070	ybrigo@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.452652	310	EXECUTED	7:62019bda9ebb258937fb3ecba097010a	dropPrimaryKey tableName=NODE_ROSTER_HOST_ARTIFACTS; createIndex indexName=IDX_NR_HA_HOST, tableName=NODE_ROSTER_HOST_ARTIFACTS		\N	3.5.1	\N	\N	4832483312
noderoster-1580000	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.462424	311	EXECUTED	7:67441abef35bde9717178d1f61394a2c	createProcedure		\N	3.5.1	\N	\N	4832483312
noderoster-1580100	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.474683	312	EXECUTED	7:e4c48e35927eae5c4bf1265d009a3d8f	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580100-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.478491	313	MARK_RAN	7:7ed481a975a2ab6302e3d4682020ef11	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580110	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.487666	314	EXECUTED	7:b6694c0295116e16f34a2f5309154750	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580110-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.493332	315	MARK_RAN	7:5b59f1f785b8ddd29c35635618a71aab	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580120	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.507246	316	EXECUTED	7:37ee572f14893dfac82eb5ccbb2e6d50	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580120-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.516913	317	MARK_RAN	7:041c98f1d0b650206d8bbaf91e03527f	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580130	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.528799	318	EXECUTED	7:5e9383fca3dcded9d1d9225a6e7a175c	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580130-a	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.532455	319	MARK_RAN	7:df4d52df2a323b38c4bcb326e6fde7b2	sql		\N	3.5.1	\N	\N	4832483312
noderoster-1580200	ibodrov@gmail.com	com/walmartlabs/concord/server/plugins/noderoster/db/liquibase.xml	2021-03-04 04:34:43.543015	320	EXECUTED	7:bd5f7e8b2040a1b0aab54759ac0ea429	sql		\N	3.5.1	\N	\N	4832483312
\.


--
-- Data for Name: task_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_locks (lock_key, locked, locked_at, lock_counter) FROM stdin;
apiKeyNotifier	f	\N	0
githubWebhookService	f	\N	0
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (task_id, task_interval, task_status, started_at, finished_at, last_updated_at, last_error_at, last_error) FROM stdin;
api-key-cleanup	0	\N	\N	\N	\N	\N	\N
api-key-expiration-notifier	0	\N	\N	\N	\N	\N	\N
audit-log-cleaner	3600	OK	2021-03-31 02:38:40.2756+00	2021-03-31 02:38:40.437314+00	2021-03-31 02:38:40.437314+00	\N	\N
process-cleaner	3600	OK	2021-03-31 02:38:40.2756+00	2021-03-31 02:38:40.513918+00	2021-03-31 02:38:40.513918+00	\N	\N
user-ldap-group-sync	86400	OK	2021-03-31 02:38:40.2756+00	2021-03-31 02:38:40.723771+00	2021-03-31 02:38:40.723771+00	\N	\N
noderoster/ansible-events-processor	10	OK	2021-03-31 02:54:41.193028+00	2021-03-31 02:54:41.204278+00	2021-03-31 02:54:41.204278+00	\N	\N
ansible-event-processor	10	OK	2021-03-31 02:54:42.201083+00	2021-03-31 02:54:42.213254+00	2021-03-31 02:54:42.213254+00	\N	\N
process-locks-watchdog	5	OK	2021-03-31 02:54:45.215762+00	2021-03-31 02:54:45.221775+00	2021-03-31 02:54:45.221775+00	\N	\N
process-queue-watchdog	3	OK	2021-03-31 02:54:45.215762+00	2021-03-31 02:54:45.228858+00	2021-03-31 02:54:45.228858+00	\N	\N
trigger-scheduler	60	OK	2021-03-31 02:54:46.223421+00	2021-03-31 02:54:46.228805+00	2021-03-31 02:54:46.228805+00	\N	\N
agent-command-watchdog	60	OK	2021-03-31 02:54:46.223421+00	2021-03-31 02:54:46.229184+00	2021-03-31 02:54:46.229184+00	\N	\N
process-wait-watchdog	5	OK	2021-03-31 02:54:47.230544+00	2021-03-31 02:54:47.249508+00	2021-03-31 02:54:47.249508+00	\N	\N
\.


--
-- Data for Name: team_ldap_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_ldap_groups (team_id, ldap_group, team_role) FROM stdin;
00000000-0000-0000-0000-000000000000	cn=concord-admins,ou=Groups,dc=walmartlabs,dc=com	OWNER
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (team_id, team_name, description, org_id) FROM stdin;
00000000-0000-0000-0000-000000000000	default	Default team	0fac1b18-d179-11e7-b3e7-d7df4543ed4f
ad76f1e2-c33c-11e7-8064-f7371c66fa77	default	Concord System Team	94a35e54-d204-11e7-9a97-c32b8f0c3380
\.


--
-- Data for Name: template_aliases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.template_aliases (template_alias, template_url) FROM stdin;
\.


--
-- Data for Name: trigger_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trigger_schedule (trigger_id, fire_at) FROM stdin;
\.


--
-- Data for Name: triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.triggers (trigger_id, project_id, repo_id, event_source, arguments, conditions, active_profiles, trigger_cfg) FROM stdin;
e9c28a58-7ca2-11eb-88f0-02420a800003	ad76f1e2-c33c-11e7-8064-f7371c66fa77	b31b0b06-c33c-11e7-b0e9-8702fc03629f	concord	\N	{"event": "repository.*", "version": 2}	\N	{"entryPoint": "onChange"}
e9c24336-7ca2-11eb-88f0-02420a800003	ad76f1e2-c33c-11e7-8064-f7371c66fa77	b31b0b06-c33c-11e7-b0e9-8702fc03629f	github	\N	{"type": "push", "branch": ".*", "version": 2, "githubOrg": ".*", "githubRepo": ".*", "repositoryInfo": [{"enabled": true, "repository": ".*"}]}	\N	{"entryPoint": "onChange"}
\.


--
-- Data for Name: user_ldap_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_ldap_groups (user_id, ldap_group) FROM stdin;
fde76d6e-7ca2-11eb-88f0-02420a800003	cn=concord-admins,ou=Groups,dc=walmartlabs,dc=com
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_id, role_id) FROM stdin;
acc17a02-b471-46af-9914-48cba3dd31ab	21d646b2-6a9c-11e8-acce-d37cf888abd9
1f9ae527-e7ab-42c0-b0e5-0092f9285f22	21d646b2-6a9c-11e8-acce-d37cf888abd9
d4f123c1-f8d4-40b2-8a12-b8947b9ce2d8	21d646b2-6a9c-11e8-acce-d37cf888abd9
d4f123c1-f8d4-40b2-8a12-b8947b9ce2d8	c162d868-89ea-11e8-80be-97fd8a9f7419
acc17a02-b471-46af-9914-48cba3dd31ab	c162d868-89ea-11e8-80be-97fd8a9f7419
230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	eabcd922-7ca2-11eb-88f0-02420a800003
\.


--
-- Data for Name: user_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_teams (user_id, team_id, team_role) FROM stdin;
acc17a02-b471-46af-9914-48cba3dd31ab	00000000-0000-0000-0000-000000000000	MEMBER
230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	00000000-0000-0000-0000-000000000000	OWNER
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, display_name, user_type, user_email, is_disabled, last_group_sync_dt, domain) FROM stdin;
230c5c9c-d9a7-11e6-bcfd-bb681c07b26c	admin	\N	LOCAL	\N	f	\N	\N
acc17a02-b471-46af-9914-48cba3dd31ab	github	\N	LOCAL	\N	f	\N	\N
1f9ae527-e7ab-42c0-b0e5-0092f9285f22	cron	\N	LOCAL	\N	f	\N	\N
d4f123c1-f8d4-40b2-8a12-b8947b9ce2d8	concordagent	\N	LOCAL	\N	f	\N	\N
2599c604-1384-4660-a767-8bc03baa7a31	concordrunner	\N	LOCAL	\N	f	\N	\N
fde76d6e-7ca2-11eb-88f0-02420a800003	concord-admin	\N	LDAP	\N	f	2021-03-31 02:38:40.698953+00	\N
\.


--
-- Name: audit_log_entry_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_entry_seq_seq', 31, true);


--
-- Name: node_roster_host_facts_seq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.node_roster_host_facts_seq_id_seq', 1, false);


--
-- Name: process_events_event_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_events_event_seq_seq', 1, false);


--
-- Name: process_log_data_log_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_log_data_log_seq_seq', 1, false);


--
-- Name: process_log_data_segment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_log_data_segment_id_seq', 1, false);


--
-- Name: process_log_segments_segment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_log_segments_segment_id_seq', 1, false);


--
-- Name: process_queue_id_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_queue_id_seq_seq', 1, false);


--
-- Name: ansible_hosts ansible_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ansible_hosts
    ADD CONSTRAINT ansible_hosts_pkey PRIMARY KEY (instance_id, instance_created_at, host, host_group, playbook_id);


--
-- Name: api_keys api_keys_api_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_api_key_key UNIQUE (api_key);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (entry_seq);


--
-- Name: json_stores inventories_org_id_inventory_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_stores
    ADD CONSTRAINT inventories_org_id_inventory_name_key UNIQUE (org_id, json_store_name);


--
-- Name: node_roster_hosts node_roster_hosts_normalized_hostname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.node_roster_hosts
    ADD CONSTRAINT node_roster_hosts_normalized_hostname_key UNIQUE (normalized_hostname);


--
-- Name: organizations organizations_org_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_org_name_key UNIQUE (org_name);


--
-- Name: agent_commands pk_agent_commands; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_commands
    ADD CONSTRAINT pk_agent_commands PRIMARY KEY (command_id);


--
-- Name: api_keys pk_api_keys; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT pk_api_keys PRIMARY KEY (key_id);


--
-- Name: event_processor_marker pk_event_processor_marker; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_processor_marker
    ADD CONSTRAINT pk_event_processor_marker PRIMARY KEY (processor_name);


--
-- Name: json_stores pk_inventories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_stores
    ADD CONSTRAINT pk_inventories PRIMARY KEY (json_store_id);


--
-- Name: json_store_data pk_inventory_data; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_data
    ADD CONSTRAINT pk_inventory_data PRIMARY KEY (json_store_id, item_path);


--
-- Name: json_store_queries pk_inventory_queries; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_queries
    ADD CONSTRAINT pk_inventory_queries PRIMARY KEY (query_id);


--
-- Name: json_store_team_access pk_inventory_team_access; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_team_access
    ADD CONSTRAINT pk_inventory_team_access PRIMARY KEY (json_store_id, team_id);


--
-- Name: node_roster_hosts pk_node_roster_hosts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.node_roster_hosts
    ADD CONSTRAINT pk_node_roster_hosts PRIMARY KEY (host_id);


--
-- Name: node_roster_process_hosts pk_node_roster_process_hosts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.node_roster_process_hosts
    ADD CONSTRAINT pk_node_roster_process_hosts PRIMARY KEY (instance_id, instance_created_at, host_id);


--
-- Name: organizations pk_organizations; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT pk_organizations PRIMARY KEY (org_id);


--
-- Name: permissions pk_permissions; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT pk_permissions PRIMARY KEY (permission_id);


--
-- Name: policies pk_policies; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT pk_policies PRIMARY KEY (policy_id);


--
-- Name: process_checkpoints pk_process_checkpoints; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_checkpoints
    ADD CONSTRAINT pk_process_checkpoints PRIMARY KEY (checkpoint_id);


--
-- Name: process_queue pk_process_queue; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_queue
    ADD CONSTRAINT pk_process_queue PRIMARY KEY (instance_id);


--
-- Name: project_kv_store pk_project_kv; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_kv_store
    ADD CONSTRAINT pk_project_kv PRIMARY KEY (project_id, value_key);


--
-- Name: project_team_access pk_project_team_access; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_team_access
    ADD CONSTRAINT pk_project_team_access PRIMARY KEY (project_id, team_id);


--
-- Name: projects pk_projects; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT pk_projects PRIMARY KEY (project_id);


--
-- Name: repositories pk_repositories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT pk_repositories PRIMARY KEY (repo_id);


--
-- Name: role_permissions pk_role_permissions; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT pk_role_permissions PRIMARY KEY (role_id, permission_id);


--
-- Name: roles pk_roles; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT pk_roles PRIMARY KEY (role_id);


--
-- Name: secret_team_access pk_secret_team_access; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secret_team_access
    ADD CONSTRAINT pk_secret_team_access PRIMARY KEY (secret_id, team_id);


--
-- Name: secrets pk_secrets; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT pk_secrets PRIMARY KEY (secret_id);


--
-- Name: server_db_lock pk_server_db_lock; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_db_lock
    ADD CONSTRAINT pk_server_db_lock PRIMARY KEY (id);


--
-- Name: task_locks pk_task_locks; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_locks
    ADD CONSTRAINT pk_task_locks PRIMARY KEY (lock_key);


--
-- Name: tasks pk_tasks; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT pk_tasks PRIMARY KEY (task_id);


--
-- Name: teams pk_teams; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT pk_teams PRIMARY KEY (team_id);


--
-- Name: template_aliases pk_template_aliases; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_aliases
    ADD CONSTRAINT pk_template_aliases PRIMARY KEY (template_alias);


--
-- Name: triggers pk_triggers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT pk_triggers PRIMARY KEY (trigger_id);


--
-- Name: user_roles pk_user_roles; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT pk_user_roles PRIMARY KEY (user_id, role_id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (user_id);


--
-- Name: policies policies_policy_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_policy_name_key UNIQUE (policy_name);


--
-- Name: process_events process_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_events
    ADD CONSTRAINT process_events_pkey PRIMARY KEY (event_seq);


--
-- Name: process_state process_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_state
    ADD CONSTRAINT process_state_pkey PRIMARY KEY (instance_id, instance_created_at, item_path);


--
-- Name: projects projects_org_id_project_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_org_id_project_name_key UNIQUE (org_id, project_name);


--
-- Name: repositories repositories_project_id_repo_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT repositories_project_id_repo_name_key UNIQUE (project_id, repo_name);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: secrets secrets_org_id_secret_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT secrets_org_id_secret_name_key UNIQUE (org_id, secret_name);


--
-- Name: team_ldap_groups team_ldap_groups_team_id_ldap_group_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_ldap_groups
    ADD CONSTRAINT team_ldap_groups_team_id_ldap_group_key UNIQUE (team_id, ldap_group);


--
-- Name: teams teams_org_id_team_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_org_id_team_name_key UNIQUE (org_id, team_name);


--
-- Name: json_store_queries unq_inventory_queries; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_queries
    ADD CONSTRAINT unq_inventory_queries UNIQUE (json_store_id, query_name);


--
-- Name: user_teams user_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_teams
    ADD CONSTRAINT user_teams_pkey PRIMARY KEY (user_id, team_id);


--
-- Name: idx_a_cmd_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_a_cmd_status ON public.agent_commands USING btree (command_status);


--
-- Name: idx_a_play_stats; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_a_play_stats ON public.ansible_play_stats USING btree (instance_id, instance_created_at, playbook_id);


--
-- Name: idx_a_playbook_result; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_a_playbook_result ON public.ansible_playbook_result USING btree (instance_id, instance_created_at, playbook_id);


--
-- Name: idx_a_playbook_stats; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_a_playbook_stats ON public.ansible_playbook_stats USING btree (instance_id, instance_created_at);


--
-- Name: idx_a_task_stats; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_a_task_stats ON public.ansible_task_stats USING btree (instance_id, instance_created_at, play_id);


--
-- Name: idx_api_key_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_key_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_api_keys_name_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_api_keys_name_user ON public.api_keys USING btree (key_name, user_id);


--
-- Name: idx_audit_log_details; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_details ON public.audit_log USING gin (entry_details);


--
-- Name: idx_checkpoints_proc_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_checkpoints_proc_id ON public.process_checkpoints USING btree (instance_id);


--
-- Name: idx_nr_ha_host; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_nr_ha_host ON public.node_roster_host_artifacts USING btree (host_id);


--
-- Name: idx_nr_hf_host; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_nr_hf_host ON public.node_roster_host_facts USING btree (host_id);


--
-- Name: idx_pld_ids; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pld_ids ON public.process_log_data USING btree (instance_id, instance_created_at, segment_id);


--
-- Name: idx_pls_ids; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pls_ids ON public.process_log_segments USING btree (instance_id, instance_created_at);


--
-- Name: idx_policy_link_1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_policy_link_1 ON public.policy_links USING btree (org_id, project_id, policy_id) WHERE ((org_id IS NOT NULL) AND (project_id IS NOT NULL));


--
-- Name: idx_policy_link_2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_policy_link_2 ON public.policy_links USING btree (policy_id) WHERE ((org_id IS NULL) AND (project_id IS NULL));


--
-- Name: idx_policy_link_3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_policy_link_3 ON public.policy_links USING btree (org_id, policy_id) WHERE ((org_id IS NOT NULL) AND (project_id IS NULL));


--
-- Name: idx_policy_link_4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_policy_link_4 ON public.policy_links USING btree (project_id, policy_id) WHERE ((org_id IS NULL) AND (project_id IS NOT NULL));


--
-- Name: idx_policy_link_5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_policy_link_5 ON public.policy_links USING btree (org_id, project_id, policy_id, user_id) WHERE ((org_id IS NOT NULL) AND (project_id IS NOT NULL) AND (user_id IS NOT NULL));


--
-- Name: idx_policy_link_6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_policy_link_6 ON public.policy_links USING btree (user_id, policy_id) WHERE ((org_id IS NULL) AND (project_id IS NULL) AND (user_id IS NOT NULL));


--
-- Name: idx_proc_enqueued; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_enqueued ON public.process_queue USING btree (current_status) WHERE ((current_status)::text = 'ENQUEUED'::text);


--
-- Name: idx_proc_events; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_events ON public.process_events USING btree (instance_id, instance_created_at, event_date, event_type);


--
-- Name: idx_proc_events_folding; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_events_folding ON public.process_events USING btree (event_seq, event_type);


--
-- Name: idx_proc_initiator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_initiator_id ON public.process_queue USING btree (initiator_id);


--
-- Name: idx_proc_meta; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_meta ON public.process_queue USING gin (meta jsonb_path_ops);


--
-- Name: idx_proc_q_c_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_q_c_status ON public.process_queue USING btree (current_status);


--
-- Name: idx_proc_q_cr_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_q_cr_at ON public.process_queue USING btree (created_at);


--
-- Name: idx_proc_q_par_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_q_par_id ON public.process_queue USING btree (parent_instance_id);


--
-- Name: idx_proc_q_prj_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_q_prj_id ON public.process_queue USING btree (project_id);


--
-- Name: idx_proc_wait_cond_nn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_proc_wait_cond_nn ON public.process_queue USING btree (instance_id) WHERE (wait_conditions IS NOT NULL);


--
-- Name: idx_process_locks_1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_process_locks_1 ON public.process_locks USING btree (org_id, lock_name) WHERE (lock_scope = 'ORG'::public.process_lock_scope);


--
-- Name: idx_process_locks_2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_process_locks_2 ON public.process_locks USING btree (project_id, lock_name) WHERE (lock_scope = 'PROJECT'::public.process_lock_scope);


--
-- Name: idx_trig_ev_src; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trig_ev_src ON public.triggers USING btree (event_source);


--
-- Name: idx_trigger_pr_id_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trigger_pr_id_repo_id ON public.triggers USING btree (project_id, repo_id);


--
-- Name: idx_trigger_sched_fire_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trigger_sched_fire_date ON public.trigger_schedule USING btree (fire_at);


--
-- Name: idx_user_ldap_groups_groups; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_ldap_groups_groups ON public.user_ldap_groups USING btree (ldap_group);


--
-- Name: idx_users_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_uniq ON public.users USING btree (lower((username)::text), lower((domain)::text), user_type);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING gin (username public.gin_trgm_ops);


--
-- Name: admins fk_admins_u_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT fk_admins_u_id FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: api_keys fk_api_key_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT fk_api_key_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: json_stores fk_inv_org_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_stores
    ADD CONSTRAINT fk_inv_org_id FOREIGN KEY (org_id) REFERENCES public.organizations(org_id) ON DELETE CASCADE;


--
-- Name: json_store_team_access fk_inv_t_a_inv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_team_access
    ADD CONSTRAINT fk_inv_t_a_inv FOREIGN KEY (json_store_id) REFERENCES public.json_stores(json_store_id) ON DELETE CASCADE;


--
-- Name: json_store_team_access fk_inv_t_a_t; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_team_access
    ADD CONSTRAINT fk_inv_t_a_t FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: json_stores fk_inventories_own_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_stores
    ADD CONSTRAINT fk_inventories_own_id FOREIGN KEY (owner_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: json_stores fk_inventories_parent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_stores
    ADD CONSTRAINT fk_inventories_parent FOREIGN KEY (parent_inventory_id) REFERENCES public.json_stores(json_store_id) ON DELETE CASCADE;


--
-- Name: json_store_data fk_inventory_data_inventory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_data
    ADD CONSTRAINT fk_inventory_data_inventory FOREIGN KEY (json_store_id) REFERENCES public.json_stores(json_store_id) ON DELETE CASCADE;


--
-- Name: json_store_queries fk_inventory_queries_inventory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.json_store_queries
    ADD CONSTRAINT fk_inventory_queries_inventory FOREIGN KEY (json_store_id) REFERENCES public.json_stores(json_store_id) ON DELETE CASCADE;


--
-- Name: organizations fk_org_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT fk_org_owner_id FOREIGN KEY (owner_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: policies fk_policies_parent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT fk_policies_parent FOREIGN KEY (parent_policy_id) REFERENCES public.policies(policy_id) ON DELETE SET NULL;


--
-- Name: policy_links fk_policy_link_policy_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_links
    ADD CONSTRAINT fk_policy_link_policy_id FOREIGN KEY (policy_id) REFERENCES public.policies(policy_id) ON DELETE CASCADE;


--
-- Name: policy_links fk_policy_link_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_links
    ADD CONSTRAINT fk_policy_link_project_id FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: policy_links fk_policy_link_repo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_links
    ADD CONSTRAINT fk_policy_link_repo_id FOREIGN KEY (org_id) REFERENCES public.organizations(org_id) ON DELETE CASCADE;


--
-- Name: policy_links fk_policy_links_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_links
    ADD CONSTRAINT fk_policy_links_user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: process_queue fk_pq_initiator_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_queue
    ADD CONSTRAINT fk_pq_initiator_id FOREIGN KEY (initiator_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: process_queue fk_pq_prj_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_queue
    ADD CONSTRAINT fk_pq_prj_id FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE SET NULL;


--
-- Name: process_queue fk_pq_repo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_queue
    ADD CONSTRAINT fk_pq_repo_id FOREIGN KEY (repo_id) REFERENCES public.repositories(repo_id) ON DELETE SET NULL;


--
-- Name: secrets fk_prj_id_secrets; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT fk_prj_id_secrets FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: projects fk_prj_org_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_prj_org_id FOREIGN KEY (org_id) REFERENCES public.organizations(org_id) ON DELETE CASCADE;


--
-- Name: projects fk_prj_own_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_prj_own_id FOREIGN KEY (owner_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: project_team_access fk_prj_t_a_prj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_team_access
    ADD CONSTRAINT fk_prj_t_a_prj FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: project_team_access fk_prj_t_a_t; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_team_access
    ADD CONSTRAINT fk_prj_t_a_t FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: process_locks fk_process_locks_instance_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_locks
    ADD CONSTRAINT fk_process_locks_instance_id FOREIGN KEY (instance_id) REFERENCES public.process_queue(instance_id) ON DELETE CASCADE;


--
-- Name: process_locks fk_process_locks_org_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_locks
    ADD CONSTRAINT fk_process_locks_org_id FOREIGN KEY (org_id) REFERENCES public.organizations(org_id) ON DELETE CASCADE;


--
-- Name: process_locks fk_process_locks_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_locks
    ADD CONSTRAINT fk_process_locks_project_id FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: repositories fk_repo_prj_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT fk_repo_prj_id FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: role_permissions fk_role_permissions; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT fk_role_permissions FOREIGN KEY (permission_id) REFERENCES public.permissions(permission_id) ON DELETE CASCADE;


--
-- Name: role_permissions fk_role_permissions_roles; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT fk_role_permissions_roles FOREIGN KEY (role_id) REFERENCES public.roles(role_id) ON DELETE CASCADE;


--
-- Name: repositories fk_rp_scr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT fk_rp_scr_id FOREIGN KEY (secret_id) REFERENCES public.secrets(secret_id) ON DELETE SET NULL;


--
-- Name: secrets fk_scrt_own_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT fk_scrt_own_id FOREIGN KEY (owner_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: secret_team_access fk_scrt_t_a_scrt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secret_team_access
    ADD CONSTRAINT fk_scrt_t_a_scrt FOREIGN KEY (secret_id) REFERENCES public.secrets(secret_id) ON DELETE CASCADE;


--
-- Name: secret_team_access fk_scrt_t_a_t; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secret_team_access
    ADD CONSTRAINT fk_scrt_t_a_t FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: secrets fk_secret_org_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT fk_secret_org_id FOREIGN KEY (org_id) REFERENCES public.organizations(org_id) ON DELETE CASCADE;


--
-- Name: trigger_schedule fk_trigger_schedule_tr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trigger_schedule
    ADD CONSTRAINT fk_trigger_schedule_tr_id FOREIGN KEY (trigger_id) REFERENCES public.triggers(trigger_id) ON DELETE CASCADE;


--
-- Name: triggers fk_triggers_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT fk_triggers_project_id FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: triggers fk_triggers_repo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT fk_triggers_repo_id FOREIGN KEY (repo_id) REFERENCES public.repositories(repo_id) ON DELETE CASCADE;


--
-- Name: user_roles fk_u_r_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_u_r_role FOREIGN KEY (role_id) REFERENCES public.roles(role_id) ON DELETE CASCADE;


--
-- Name: user_roles fk_u_r_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_u_r_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_ldap_groups fk_user_ldap_groups_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_ldap_groups
    ADD CONSTRAINT fk_user_ldap_groups_user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_teams fk_usr_teams_team; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_teams
    ADD CONSTRAINT fk_usr_teams_team FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: user_teams fk_usr_teams_usr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_teams
    ADD CONSTRAINT fk_usr_teams_usr FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

